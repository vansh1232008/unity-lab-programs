using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;

[InitializeOnLoad]
public static class ProgramScenes
{
    const string Root = "Assets/Programs";
    static string gen = "Assets/Programs";
    static readonly string[] Names = { "P1", "P2", "P3", "P4", "P5" };

    static ProgramScenes()
    {
        EditorApplication.delayCall += AutoBuild;
    }

    static void AutoBuild()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
        {
            EditorApplication.playModeStateChanged -= OnPlayMode;
            EditorApplication.playModeStateChanged += OnPlayMode;
            return;
        }
        if (EditorApplication.isCompiling || EditorApplication.isUpdating)
        {
            EditorApplication.delayCall += AutoBuild;
            return;
        }
        bool missing = false;
        foreach (var n in Names)
            if (!File.Exists(ScenePath(n))) missing = true;
        if (!missing) return;
        for (int i = 0; i < SceneManager.sceneCount; i++)
            if (SceneManager.GetSceneAt(i).isDirty)
            {
                Debug.LogWarning("[Programs] Save your open scene, then use the menu Programs > Rebuild All Program Scenes.");
                return;
            }
        Build(false);
    }

    static void OnPlayMode(PlayModeStateChange change)
    {
        if (change != PlayModeStateChange.EnteredEditMode) return;
        EditorApplication.playModeStateChanged -= OnPlayMode;
        EditorApplication.delayCall += AutoBuild;
    }

    [MenuItem("Programs/Rebuild All Program Scenes")]
    static void RebuildAll()
    {
        if (EditorApplication.isPlaying)
        {
            EditorUtility.DisplayDialog("Programs", "Stop Play mode first, then run this again.", "OK");
            return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Build(true);
    }

    public static void BuildFromCommandLine()
    {
        Build(true);
    }

    static string ScenePath(string n) => $"{Root}/{n}/{n}.unity";

    static void Build(bool force)
    {
        string previous = SceneManager.GetActiveScene().path;
        var builders = new Action[] { BuildP1, BuildP2, BuildP3, BuildP4, BuildP5 };
        for (int i = 0; i < Names.Length; i++)
        {
            string path = ScenePath(Names[i]);
            if (!force && File.Exists(path)) continue;
            string folder = $"{Root}/{Names[i]}";
            if (!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder(Root, Names[i]);
            gen = folder + "/Generated";
            if (i < 4 && !AssetDatabase.IsValidFolder(gen)) AssetDatabase.CreateFolder(folder, "Generated");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            builders[i]();
            EditorSceneManager.SaveScene(scene, path);
            Debug.Log("[Programs] Created " + path);
        }
        WriteMarkerPng();
        var list = new List<EditorBuildSettingsScene>();
        foreach (var n in Names) list.Add(new EditorBuildSettingsScene(ScenePath(n), true));
        foreach (var s in EditorBuildSettings.scenes)
            if (!list.Exists(x => x.path == s.path) && File.Exists(s.path)) list.Add(s);
        EditorBuildSettings.scenes = list.ToArray();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorSceneManager.OpenScene(string.IsNullOrEmpty(previous) || !File.Exists(previous) ? ScenePath("P1") : previous);
    }

    static void WriteMarkerPng()
    {
        string path = Root + "/P5/P5_PrintThisMarker.png";
        File.WriteAllBytes(path, MarkerDictionary.CreateTexture(0, 60, 1).EncodeToPNG());
        AssetDatabase.ImportAsset(path);
    }

    static Material Mat(string name, Color c)
    {
        string path = $"{gen}/{name}.mat";
        var m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m == null)
        {
            m = new Material(Shader.Find("Standard"));
            AssetDatabase.CreateAsset(m, path);
        }
        m.shader = Shader.Find("Standard");
        m.color = c;
        EditorUtility.SetDirty(m);
        return m;
    }

    static GameObject Prim(PrimitiveType type, string name, Transform parent, Vector3 pos, Vector3 scale, Material m)
    {
        var go = GameObject.CreatePrimitive(type);
        go.name = name;
        if (parent != null) go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = m;
        return go;
    }

    static Camera MainCam()
    {
        var go = GameObject.Find("Main Camera");
        return go != null ? go.GetComponent<Camera>() : null;
    }

    static void PlaceCamera(Vector3 pos, Vector3 lookAt)
    {
        var cam = MainCam();
        cam.transform.position = pos;
        cam.transform.LookAt(lookAt);
    }

    static void BuildP1()
    {
        Prim(PrimitiveType.Plane, "Plane", null, Vector3.zero, new Vector3(2f, 1f, 2f), Mat("Plane", new Color(0.45f, 0.65f, 0.4f)));
        var cube = Prim(PrimitiveType.Cube, "Cube", null, new Vector3(-2f, 0.5f, 0f), Vector3.one, Mat("Cube", new Color(0.25f, 0.5f, 0.95f)));
        var sphere = Prim(PrimitiveType.Sphere, "Sphere", null, new Vector3(2f, 0.5f, 0f), Vector3.one, Mat("Sphere", new Color(0.95f, 0.3f, 0.3f)));
        cube.AddComponent<geoTransform>().speed = 3f;
        sphere.AddComponent<geoTransform>().speed = 6f;
        PlaceCamera(new Vector3(0f, 6f, -10f), new Vector3(0f, 0.5f, 0f));
    }

    static Font UIFont()
    {
#if UNITY_2022_2_OR_NEWER
        return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
    }

    static RectTransform UIRect(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        var rt = (RectTransform)go.transform;
        rt.anchorMin = rt.anchorMax = anchor;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return rt;
    }

    static Image UIImage(RectTransform rt, string sprite, Color color)
    {
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>(sprite);
        img.type = Image.Type.Sliced;
        img.color = color;
        return img;
    }

    static Text UIText(Transform parent, string text, int size, Color color)
    {
        var rt = UIRect("Text", parent, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        var t = rt.gameObject.AddComponent<Text>();
        t.font = UIFont();
        t.text = text;
        t.fontSize = size;
        t.fontStyle = FontStyle.Bold;
        t.alignment = TextAnchor.MiddleCenter;
        t.color = color;
        return t;
    }

    static Button UIButton(string name, Transform parent, Vector2 anchor, Vector2 pos, string label)
    {
        var b = UIRect(name, parent, anchor, pos, new Vector2(260, 90));
        var img = UIImage(b, "UI/Skin/UISprite.psd", Color.white);
        var button = b.gameObject.AddComponent<Button>();
        button.targetGraphic = img;
        UIText(b, label, 36, new Color(0.15f, 0.15f, 0.2f));
        return button;
    }

    static void BuildP2()
    {
        Prim(PrimitiveType.Plane, "Plane", null, Vector3.zero, new Vector3(2f, 1f, 2f), Mat("Ground", new Color(0.45f, 0.5f, 0.55f)));
        var screenMat = new Material(Shader.Find("Unlit/Texture"));
        AssetDatabase.CreateAsset(screenMat, $"{gen}/ScreenMaterial.mat");
        var screen = GameObject.CreatePrimitive(PrimitiveType.Quad);
        screen.name = "Screen";
        screen.transform.position = new Vector3(0f, 2.2f, 3f);
        screen.transform.localScale = new Vector3(6.4f, 3.6f, 1f);
        var screenRenderer = screen.GetComponent<Renderer>();
        screenRenderer.sharedMaterial = screenMat;
        var vp = screen.AddComponent<UnityEngine.Video.VideoPlayer>();
        vp.clip = AssetDatabase.LoadAssetAtPath<UnityEngine.Video.VideoClip>(Root + "/P2/Prog2Video.mp4");
        vp.playOnAwake = false;
        vp.isLooping = true;
        vp.renderMode = UnityEngine.Video.VideoRenderMode.MaterialOverride;
        vp.targetMaterialRenderer = screenRenderer;
        vp.targetMaterialProperty = "_MainTex";
        vp.audioOutputMode = UnityEngine.Video.VideoAudioOutputMode.None;
        PlaceCamera(new Vector3(0f, 2.2f, -4.5f), new Vector3(0f, 2f, 3f));

        var canvasGo = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasGo.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 1f;
        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        var statusBox = UIRect("Status Image", canvasGo.transform, new Vector2(0.5f, 1f), new Vector2(0, -60), new Vector2(560, 80));
        UIImage(statusBox, "UI/Skin/Background.psd", new Color(0.1f, 0.12f, 0.18f, 0.85f));
        var status = UIText(statusBox, "Video: Stopped", 36, new Color(1f, 0.9f, 0.4f));

        var controller = new GameObject("VideoController").AddComponent<VideoController>();
        controller.videoPlayer = vp;
        controller.status = status;

        var play = UIButton("Play Button", canvasGo.transform, new Vector2(0.5f, 0f), new Vector2(-150, 80), "Play");
        var pause = UIButton("Pause Button", canvasGo.transform, new Vector2(0.5f, 0f), new Vector2(150, 80), "Pause");
        UnityEventTools.AddPersistentListener(play.onClick, new UnityAction(controller.PlayVideo));
        UnityEventTools.AddPersistentListener(pause.onClick, new UnityAction(controller.PauseVideo));
    }

    static void BuildP3()
    {
        Prim(PrimitiveType.Plane, "Plane", null, Vector3.zero, new Vector3(3f, 1f, 3f), Mat("Ground", new Color(0.45f, 0.65f, 0.4f)));
        Prim(PrimitiveType.Cube, "Cube", null, new Vector3(-4f, 1f, 4f), new Vector3(2f, 2f, 2f), Mat("Cube Red", new Color(0.9f, 0.3f, 0.25f)));
        Prim(PrimitiveType.Cube, "Cube (1)", null, new Vector3(5f, 1.5f, 6f), new Vector3(2f, 3f, 2f), Mat("Cube Blue", new Color(0.25f, 0.45f, 0.9f)));
        Prim(PrimitiveType.Cube, "Cube (2)", null, new Vector3(0f, 0.75f, 9f), new Vector3(4f, 1.5f, 1.5f), Mat("Cube Yellow", new Color(0.95f, 0.8f, 0.2f)));
        Prim(PrimitiveType.Cube, "Cube (3)", null, new Vector3(-7f, 2f, -3f), new Vector3(1.5f, 4f, 1.5f), Mat("Cube Purple", new Color(0.6f, 0.35f, 0.85f)));
        var player = Prim(PrimitiveType.Capsule, "Capsule", null, new Vector3(0f, 1f, -6f), Vector3.one, Mat("Player", new Color(0.95f, 0.95f, 0.95f)));
        player.AddComponent<FirstPersonController>();
        var cam = MainCam();
        cam.transform.SetParent(player.transform, false);
        cam.transform.localPosition = new Vector3(0f, 0.6f, 0f);
        cam.transform.localRotation = Quaternion.identity;
        cam.nearClipPlane = 0.1f;
    }

    static Sprite MakeSprite(string name, int w, int h, Func<float, float, bool> inside)
    {
        var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
        var px = new Color32[w * h];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
            px[y * w + x] = inside((x + 0.5f) / w, (y + 0.5f) / h) ? new Color32(255, 255, 255, 255) : new Color32(255, 255, 255, 0);
        tex.SetPixels32(px);
        tex.Apply();
        string path = $"{gen}/{name}.png";
        File.WriteAllBytes(path, tex.EncodeToPNG());
        Object.DestroyImmediate(tex);
        AssetDatabase.ImportAsset(path);
        var importer = (TextureImporter)AssetImporter.GetAtPath(path);
        importer.textureType = TextureImporterType.Sprite;
        importer.spriteImportMode = SpriteImportMode.Single;
        importer.spritePixelsPerUnit = w;
        importer.alphaIsTransparency = true;
        importer.SaveAndReimport();
        return AssetDatabase.LoadAssetAtPath<Sprite>(path);
    }

    static GameObject SpriteObject(string name, Transform parent, Sprite sprite, Vector2 pos, Vector2 scale, Color color, int order)
    {
        var go = new GameObject(name);
        if (parent != null) go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = new Vector3(scale.x, scale.y, 1f);
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.color = color;
        sr.sortingOrder = order;
        return go;
    }

    static void BuildP4()
    {
        var square = MakeSprite("Square", 32, 32, (u, v) => true);
        var circle = MakeSprite("Circle", 64, 64, (u, v) => (u - 0.5f) * (u - 0.5f) + (v - 0.5f) * (v - 0.5f) <= 0.25f);
        var diamond = MakeSprite("Diamond", 64, 64, (u, v) => Mathf.Abs(u - 0.5f) + Mathf.Abs(v - 0.5f) <= 0.5f);

        var cam = MainCam();
        cam.orthographic = true;
        cam.orthographicSize = 5f;
        cam.transform.position = new Vector3(0f, 0f, -10f);
        cam.transform.rotation = Quaternion.identity;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.12f, 0.14f, 0.2f);
        Object.DestroyImmediate(GameObject.Find("Directional Light"));

        var sq = SpriteObject("Square", null, square, new Vector2(3f, 2.5f), new Vector2(1.6f, 1.6f), Color.red, 1);
        sq.AddComponent<BoxCollider2D>();
        var ci = SpriteObject("Circle", null, circle, new Vector2(5f, -1.5f), new Vector2(1.8f, 1.8f), Color.red, 1);
        ci.AddComponent<CircleCollider2D>();
        var di = SpriteObject("Diamond", null, diamond, new Vector2(0.5f, -3f), new Vector2(1.8f, 1.8f), Color.red, 1);
        di.AddComponent<PolygonCollider2D>();

        var shooter = SpriteObject("Ray Origin", null, circle, new Vector2(-6.5f, 0f), new Vector2(0.8f, 0.8f), new Color(0.3f, 0.7f, 1f), 2);
        var line = shooter.AddComponent<LineRenderer>();
        var lineMat = new Material(Shader.Find("Sprites/Default"));
        AssetDatabase.CreateAsset(lineMat, $"{gen}/RayLine.mat");
        line.sharedMaterial = lineMat;
        line.positionCount = 2;
        line.useWorldSpace = true;
        line.startWidth = line.endWidth = 0.06f;
        line.startColor = line.endColor = new Color(1f, 0.9f, 0.2f);
        line.sortingOrder = 3;
        var rc = shooter.AddComponent<RayCast2D>();
        rc.line = line;
    }

    static void BuildP5()
    {
        new GameObject("Marker AR").AddComponent<P5MarkerAR>();
    }
}
