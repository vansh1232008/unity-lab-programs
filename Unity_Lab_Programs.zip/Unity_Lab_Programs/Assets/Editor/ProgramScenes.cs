using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;

[InitializeOnLoad]
public static class ProgramScenes
{
    const string Root = "Assets/Programs";
    static string gen = "Assets/Programs";
    static readonly string[] Names = { "P1", "P2", "P3", "P4", "P5" };

    static ProgramScenes()
    {
        EditorApplication.delayCall += AutoBuild;
    }

    static void AutoBuild()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
        {
            EditorApplication.playModeStateChanged -= OnPlayMode;
            EditorApplication.playModeStateChanged += OnPlayMode;
            return;
        }
        if (EditorApplication.isCompiling || EditorApplication.isUpdating)
        {
            EditorApplication.delayCall += AutoBuild;
            return;
        }
        bool missing = false;
        foreach (var n in Names)
            if (!File.Exists(ScenePath(n))) missing = true;
        if (!missing) return;
        for (int i = 0; i < SceneManager.sceneCount; i++)
            if (SceneManager.GetSceneAt(i).isDirty)
            {
                Debug.LogWarning("[Programs] Save your open scene, then use the menu Programs > Rebuild All Program Scenes.");
                return;
            }
        Build(false);
    }

    static void OnPlayMode(PlayModeStateChange change)
    {
        if (change != PlayModeStateChange.EnteredEditMode) return;
        EditorApplication.playModeStateChanged -= OnPlayMode;
        EditorApplication.delayCall += AutoBuild;
    }

    [MenuItem("Programs/Rebuild All Program Scenes")]
    static void RebuildAll()
    {
        if (EditorApplication.isPlaying)
        {
            EditorUtility.DisplayDialog("Programs", "Stop Play mode first, then run this again.", "OK");
            return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Build(true);
    }

    static string ScenePath(string n) => $"{Root}/{n}/{n}.unity";

    static void Build(bool force)
    {
        string previous = SceneManager.GetActiveScene().path;
        var builders = new Action[] { BuildP1, BuildP2, BuildP3, BuildP4, BuildP5 };
        for (int i = 0; i < Names.Length; i++)
        {
            string path = ScenePath(Names[i]);
            if (!force && File.Exists(path)) continue;
            string folder = $"{Root}/{Names[i]}";
            if (!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder(Root, Names[i]);
            gen = folder + "/Generated";
            if (i < 3 && !AssetDatabase.IsValidFolder(gen)) AssetDatabase.CreateFolder(folder, "Generated");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            builders[i]();
            EditorSceneManager.SaveScene(scene, path);
            Debug.Log("[Programs] Created " + path);
        }
        WriteMarkerPng();
        var list = new List<EditorBuildSettingsScene>();
        foreach (var n in Names) list.Add(new EditorBuildSettingsScene(ScenePath(n), true));
        foreach (var s in EditorBuildSettings.scenes)
            if (!list.Exists(x => x.path == s.path)) list.Add(s);
        EditorBuildSettings.scenes = list.ToArray();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorSceneManager.OpenScene(string.IsNullOrEmpty(previous) || !File.Exists(previous) ? ScenePath("P1") : previous);
    }

    static void WriteMarkerPng()
    {
        string path = Root + "/P5/P5_PrintThisMarker.png";
        File.WriteAllBytes(path, MarkerDictionary.CreateTexture(0, 60, 1).EncodeToPNG());
        AssetDatabase.ImportAsset(path);
    }

    static Material Mat(string name, Color c)
    {
        string path = $"{gen}/{name}.mat";
        var m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m == null)
        {
            m = new Material(Shader.Find("Standard"));
            AssetDatabase.CreateAsset(m, path);
        }
        m.color = c;
        EditorUtility.SetDirty(m);
        return m;
    }

    static GameObject Prim(PrimitiveType type, string name, Transform parent, Vector3 pos, Vector3 scale, Material m)
    {
        var go = GameObject.CreatePrimitive(type);
        go.name = name;
        if (parent != null) go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = m;
        return go;
    }

    static Camera MainCam()
    {
        var go = GameObject.Find("Main Camera");
        return go != null ? go.GetComponent<Camera>() : null;
    }

    static void PlaceCamera(Vector3 pos, Vector3 euler)
    {
        var cam = MainCam();
        cam.transform.position = pos;
        cam.transform.eulerAngles = euler;
    }

    static void BuildP1()
    {
        Prim(PrimitiveType.Plane, "Plane", null, Vector3.zero, new Vector3(2f, 1f, 2f), Mat("P1_Plane", new Color(0.45f, 0.65f, 0.4f)));
        var cube = Prim(PrimitiveType.Cube, "Cube", null, new Vector3(-2f, 0.5f, 0f), Vector3.one, Mat("P1_Cube", new Color(0.25f, 0.5f, 0.95f)));
        var sphere = Prim(PrimitiveType.Sphere, "Sphere", null, new Vector3(2f, 0.5f, 0f), Vector3.one, Mat("P1_Sphere", new Color(0.95f, 0.3f, 0.3f)));
        cube.AddComponent<geoTransform>().startSelected = true;
        sphere.AddComponent<geoTransform>().moveSpeed = 6f;
        PlaceCamera(new Vector3(0f, 6f, -10f), new Vector3(30f, 0f, 0f));
    }

    static Animator Character(string name, Vector3 pos, Color shirt, AnimatorController controller)
    {
        var skin = Mat("P2_Skin", new Color(0.95f, 0.78f, 0.62f));
        var shirtMat = Mat("P2_" + name.Replace(" ", "") + "_Shirt", shirt);
        var pants = Mat("P2_Pants", new Color(0.2f, 0.22f, 0.3f));
        var root = new GameObject(name);
        root.transform.position = pos;
        root.transform.eulerAngles = new Vector3(0f, 180f, 0f);
        var body = new GameObject("Body").transform;
        body.SetParent(root.transform, false);
        Prim(PrimitiveType.Cube, "Torso", body, new Vector3(0f, 1.15f, 0f), new Vector3(0.6f, 0.8f, 0.35f), shirtMat);
        Prim(PrimitiveType.Sphere, "Head", body, new Vector3(0f, 1.82f, 0f), Vector3.one * 0.48f, skin);
        Limb("ArmL", body, new Vector3(-0.4f, 1.5f, 0f), 0.7f, 0.17f, skin);
        Limb("ArmR", body, new Vector3(0.4f, 1.5f, 0f), 0.7f, 0.17f, skin);
        Limb("LegL", body, new Vector3(-0.15f, 0.75f, 0f), 0.75f, 0.22f, pants);
        Limb("LegR", body, new Vector3(0.15f, 0.75f, 0f), 0.75f, 0.22f, pants);
        foreach (var c in root.GetComponentsInChildren<Collider>()) Object.DestroyImmediate(c);
        var anim = root.AddComponent<Animator>();
        anim.runtimeAnimatorController = controller;
        anim.applyRootMotion = false;
        return anim;
    }

    static void Limb(string name, Transform parent, Vector3 pivot, float length, float thick, Material m)
    {
        var p = new GameObject(name).transform;
        p.SetParent(parent, false);
        p.localPosition = pivot;
        Prim(PrimitiveType.Cube, name + " Mesh", p, new Vector3(0f, -length * 0.5f, 0f), new Vector3(thick, length, thick), m);
    }

    static readonly string[] AnimPaths = { "Body", "Body/ArmL", "Body/ArmR", "Body/LegL", "Body/LegR" };

    static void Key(AnimationClip clip, string path, string prop, params float[] tv)
    {
        var keys = new Keyframe[tv.Length / 2];
        for (int i = 0; i < keys.Length; i++) keys[i] = new Keyframe(tv[2 * i], tv[2 * i + 1]);
        var curve = new AnimationCurve(keys);
        for (int i = 0; i < keys.Length; i++) curve.SmoothTangents(i, 0f);
        AnimationUtility.SetEditorCurve(clip, EditorCurveBinding.FloatCurve(path, typeof(Transform), prop), curve);
    }

    static AnimationClip Clip(string name, float length, bool loop, Action<AnimationClip> keys)
    {
        var clip = new AnimationClip { name = name, frameRate = 30f };
        keys(clip);
        var bound = new HashSet<string>();
        foreach (var b in AnimationUtility.GetCurveBindings(clip)) bound.Add(b.path + "|" + b.propertyName);
        foreach (var path in AnimPaths)
        {
            foreach (var axis in new[] { "x", "y", "z" })
            {
                if (!bound.Contains(path + "|localEulerAnglesRaw." + axis)) Key(clip, path, "localEulerAnglesRaw." + axis, 0f, 0f, length, 0f);
            }
        }
        foreach (var axis in new[] { "x", "y", "z" })
            if (!bound.Contains("Body|m_LocalPosition." + axis)) Key(clip, "Body", "m_LocalPosition." + axis, 0f, 0f, length, 0f);
        var settings = AnimationUtility.GetAnimationClipSettings(clip);
        settings.loopTime = loop;
        AnimationUtility.SetAnimationClipSettings(clip, settings);
        AssetDatabase.CreateAsset(clip, $"{gen}/P2_{name}.anim");
        return clip;
    }

    static void BuildP2()
    {
        const string rx = "localEulerAnglesRaw.x", ry = "localEulerAnglesRaw.y", rz = "localEulerAnglesRaw.z", py = "m_LocalPosition.y";
        var idle = Clip("Idle", 2f, true, c =>
        {
            Key(c, "Body", py, 0f, 0f, 1f, 0.03f, 2f, 0f);
            Key(c, "Body/ArmL", rz, 0f, -5f, 1f, -9f, 2f, -5f);
            Key(c, "Body/ArmR", rz, 0f, 5f, 1f, 9f, 2f, 5f);
        });
        var walk = Clip("Walk", 1f, true, c =>
        {
            Key(c, "Body/LegL", rx, 0f, 30f, 0.5f, -30f, 1f, 30f);
            Key(c, "Body/LegR", rx, 0f, -30f, 0.5f, 30f, 1f, -30f);
            Key(c, "Body/ArmL", rx, 0f, -30f, 0.5f, 30f, 1f, -30f);
            Key(c, "Body/ArmR", rx, 0f, 30f, 0.5f, -30f, 1f, 30f);
            Key(c, "Body", py, 0f, 0f, 0.25f, 0.06f, 0.5f, 0f, 0.75f, 0.06f, 1f, 0f);
        });
        var jump = Clip("Jump", 0.9f, false, c =>
        {
            Key(c, "Body", py, 0f, 0f, 0.15f, -0.12f, 0.45f, 0.9f, 0.75f, 0f, 0.9f, 0f);
            Key(c, "Body/ArmL", rz, 0f, 0f, 0.15f, -20f, 0.45f, -160f, 0.75f, -20f, 0.9f, 0f);
            Key(c, "Body/ArmR", rz, 0f, 0f, 0.15f, 20f, 0.45f, 160f, 0.75f, 20f, 0.9f, 0f);
            Key(c, "Body/LegL", rx, 0f, 0f, 0.15f, 25f, 0.45f, -10f, 0.75f, 15f, 0.9f, 0f);
            Key(c, "Body/LegR", rx, 0f, 0f, 0.15f, 25f, 0.45f, -10f, 0.75f, 15f, 0.9f, 0f);
        });
        var wave = Clip("Wave", 1.2f, true, c =>
        {
            Key(c, "Body/ArmR", rz, 0f, 140f, 0.3f, 170f, 0.6f, 140f, 0.9f, 170f, 1.2f, 140f);
            Key(c, "Body/ArmL", rz, 0f, -5f, 1.2f, -5f);
        });
        var dance = Clip("Dance", 1.6f, true, c =>
        {
            Key(c, "Body", ry, 0f, 0f, 1.6f, 360f);
            Key(c, "Body", py, 0f, 0f, 0.2f, 0.15f, 0.4f, 0f, 0.6f, 0.15f, 0.8f, 0f, 1f, 0.15f, 1.2f, 0f, 1.4f, 0.15f, 1.6f, 0f);
            Key(c, "Body/ArmL", rz, 0f, -120f, 0.4f, -170f, 0.8f, -120f, 1.2f, -170f, 1.6f, -120f);
            Key(c, "Body/ArmR", rz, 0f, 170f, 0.4f, 120f, 0.8f, 170f, 1.2f, 120f, 1.6f, 170f);
            Key(c, "Body/LegL", rx, 0f, 0f, 0.4f, 25f, 0.8f, 0f, 1.2f, 25f, 1.6f, 0f);
            Key(c, "Body/LegR", rx, 0f, 25f, 0.4f, 0f, 0.8f, 25f, 1.2f, 0f, 1.6f, 25f);
        });
        var win = Clip("Win", 1.2f, false, c =>
        {
            Key(c, "Body", py, 0f, 0f, 0.3f, 0.5f, 0.6f, 0f, 0.9f, 0.5f, 1.2f, 0f);
            Key(c, "Body/ArmL", rz, 0f, 0f, 0.2f, -165f, 1f, -165f, 1.2f, -165f);
            Key(c, "Body/ArmR", rz, 0f, 0f, 0.2f, 165f, 1f, 165f, 1.2f, 165f);
            Key(c, "Body", ry, 0f, 0f, 1.2f, 0f);
        });

        string ctrlPath = $"{gen}/P2_Character.controller";
        AssetDatabase.DeleteAsset(ctrlPath);
        var ctrl = AnimatorController.CreateAnimatorControllerAtPath(ctrlPath);
        foreach (var p in new[] { "idle", "walk", "jump", "wave", "dance", "win" })
            ctrl.AddParameter(p, AnimatorControllerParameterType.Trigger);
        var sm = ctrl.layers[0].stateMachine;
        var sIdle = sm.AddState("Idle", new Vector3(300, 0, 0));
        sIdle.motion = idle;
        sm.defaultState = sIdle;
        var sWalk = sm.AddState("Walk", new Vector3(300, 80, 0));
        sWalk.motion = walk;
        var sJump = sm.AddState("Jump", new Vector3(300, 160, 0));
        sJump.motion = jump;
        var sWave = sm.AddState("Wave", new Vector3(300, 240, 0));
        sWave.motion = wave;
        var sDance = sm.AddState("Dance", new Vector3(300, 320, 0));
        sDance.motion = dance;
        var sWin = sm.AddState("Win", new Vector3(600, 0, 0));
        sWin.motion = win;
        var sWinWave = sm.AddState("Win Wave", new Vector3(600, 80, 0));
        sWinWave.motion = wave;
        var sWinJump = sm.AddState("Win Jump", new Vector3(600, 160, 0));
        sWinJump.motion = jump;

        void Any(AnimatorState s, string trigger)
        {
            var tr = sm.AddAnyStateTransition(s);
            tr.hasExitTime = false;
            tr.duration = 0.15f;
            tr.canTransitionToSelf = false;
            tr.AddCondition(AnimatorConditionMode.If, 0f, trigger);
        }
        Any(sIdle, "idle");
        Any(sWalk, "walk");
        Any(sJump, "jump");
        Any(sWave, "wave");
        Any(sDance, "dance");
        Any(sWin, "win");

        void Then(AnimatorState from, AnimatorState to)
        {
            var tr = from.AddTransition(to);
            tr.hasExitTime = true;
            tr.exitTime = 1f;
            tr.duration = 0.15f;
        }
        Then(sJump, sIdle);
        Then(sWin, sWinWave);
        Then(sWinWave, sWinJump);
        Then(sWinJump, sIdle);
        EditorUtility.SetDirty(ctrl);

        Prim(PrimitiveType.Plane, "Ground", null, Vector3.zero, new Vector3(3f, 1f, 2f), Mat("P2_Ground", new Color(0.5f, 0.55f, 0.6f)));
        var c1 = Character("Character 1", new Vector3(0.6f, 0f, 0f), new Color(0.2f, 0.55f, 0.95f), ctrl);
        var c2 = Character("Character 2", new Vector3(3.2f, 0f, 0f), new Color(0.95f, 0.4f, 0.3f), ctrl);
        var menu = new GameObject("UI Menu").AddComponent<P2Menu>();
        menu.characters = new[] { c1, c2 };
        PlaceCamera(new Vector3(1.2f, 1.9f, -6.5f), new Vector3(6f, 0f, 0f));
    }

    static Texture2D NoiseTexture(string name, Color a, Color b, float scale)
    {
        int n = 128;
        var tex = new Texture2D(n, n, TextureFormat.RGBA32, true);
        var px = new Color[n * n];
        float ox = Random.Range(0f, 100f), oy = Random.Range(0f, 100f);
        for (int y = 0; y < n; y++)
        for (int x = 0; x < n; x++)
        {
            float u = x / (float)n, v = y / (float)n;
            float f = 0.6f * Tile(u, v, scale, ox, oy) + 0.4f * Tile(u, v, scale * 4f, ox + 33f, oy + 17f);
            px[y * n + x] = Color.Lerp(a, b, f);
        }
        tex.SetPixels(px);
        tex.Apply();
        tex.name = name;
        AssetDatabase.CreateAsset(tex, $"{gen}/{name}.asset");
        return tex;
    }

    static float Tile(float u, float v, float s, float ox, float oy)
    {
        float a = Mathf.PerlinNoise(ox + u * s, oy + v * s);
        float b = Mathf.PerlinNoise(ox + (u - 1f) * s, oy + v * s);
        float c = Mathf.PerlinNoise(ox + u * s, oy + (v - 1f) * s);
        float d = Mathf.PerlinNoise(ox + (u - 1f) * s, oy + (v - 1f) * s);
        return Mathf.Lerp(Mathf.Lerp(a, b, u), Mathf.Lerp(c, d, u), v);
    }

    static TerrainLayer Layer(string name, Texture2D tex)
    {
        var l = new TerrainLayer { diffuseTexture = tex, tileSize = new Vector2(6f, 6f) };
        AssetDatabase.CreateAsset(l, $"{gen}/{name}.terrainlayer");
        return l;
    }

    static GameObject TreePrefab()
    {
        var temp = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        var trunkMesh = temp.GetComponent<MeshFilter>().sharedMesh;
        Object.DestroyImmediate(temp);
        temp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        var leafMesh = temp.GetComponent<MeshFilter>().sharedMesh;
        Object.DestroyImmediate(temp);
        var parts = new[]
        {
            new CombineInstance { mesh = trunkMesh, transform = Matrix4x4.TRS(new Vector3(0f, 1.5f, 0f), Quaternion.identity, new Vector3(0.35f, 1.5f, 0.35f)) },
            new CombineInstance { mesh = leafMesh, transform = Matrix4x4.TRS(new Vector3(0f, 3.6f, 0f), Quaternion.identity, new Vector3(2.6f, 2.4f, 2.6f)) },
        };
        var trunk = new Mesh();
        trunk.CombineMeshes(new[] { parts[0] }, true, true);
        var leaves = new Mesh();
        leaves.CombineMeshes(new[] { parts[1] }, true, true);
        var mesh = new Mesh { name = "P3_TreeMesh" };
        mesh.CombineMeshes(new[] { new CombineInstance { mesh = trunk }, new CombineInstance { mesh = leaves } }, false, false);
        mesh.RecalculateBounds();
        AssetDatabase.CreateAsset(mesh, $"{gen}/P3_TreeMesh.asset");
        var go = new GameObject("P3_Tree");
        go.AddComponent<MeshFilter>().sharedMesh = mesh;
        var bark = Mat("P3_Bark", new Color(0.4f, 0.27f, 0.15f));
        bark.shader = Shader.Find("Nature/Tree Soft Occlusion Bark");
        bark.color = new Color(0.4f, 0.27f, 0.15f);
        var leafMat = Mat("P3_Leaves", new Color(0.2f, 0.5f, 0.18f));
        leafMat.shader = Shader.Find("Nature/Tree Soft Occlusion Leaves");
        leafMat.color = new Color(0.2f, 0.5f, 0.18f);
        go.AddComponent<MeshRenderer>().sharedMaterials = new[] { bark, leafMat };
        var col = go.AddComponent<CapsuleCollider>();
        col.radius = 0.35f;
        col.height = 3f;
        col.center = new Vector3(0f, 1.5f, 0f);
        var prefab = PrefabUtility.SaveAsPrefabAsset(go, $"{gen}/P3_Tree.prefab");
        Object.DestroyImmediate(go);
        return prefab;
    }

    static ParticleSystem Weather(string name, Transform parent, bool snow)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = new Vector3(0f, snow ? 10f : 12f, 0f);
        go.transform.localEulerAngles = new Vector3(90f, 0f, 0f);
        var ps = go.AddComponent<ParticleSystem>();
        ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        var main = ps.main;
        main.loop = true;
        main.playOnAwake = !snow;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = snow ? 4000 : 6000;
        main.startLifetime = snow ? 7f : 1.2f;
        main.startSpeed = snow ? 1.5f : 14f;
        main.startSize = snow ? 0.12f : 0.04f;
        main.gravityModifier = snow ? 0.04f : 1f;
        main.startColor = snow ? new Color(1f, 1f, 1f, 0.9f) : new Color(0.75f, 0.82f, 1f, 0.55f);
        var em = ps.emission;
        em.rateOverTime = snow ? 500f : 2500f;
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Box;
        shape.scale = new Vector3(40f, 40f, 1f);
        var ext = ps.externalForces;
        ext.enabled = true;
        ext.multiplier = snow ? 3f : 1.5f;
        if (snow)
        {
            var noise = ps.noise;
            noise.enabled = true;
            noise.strength = 0.6f;
            noise.frequency = 0.4f;
        }
        var r = go.GetComponent<ParticleSystemRenderer>();
        r.sharedMaterial = AssetDatabase.GetBuiltinExtraResource<Material>("Default-ParticleSystem.mat");
        if (!snow)
        {
            r.renderMode = ParticleSystemRenderMode.Stretch;
            r.lengthScale = 1f;
            r.velocityScale = 0.06f;
        }
        return ps;
    }

    static void BuildP3()
    {
        const int res = 257;
        var td = new TerrainData { heightmapResolution = res };
        td.size = new Vector3(200f, 25f, 200f);
        var h = new float[res, res];
        for (int y = 0; y < res; y++)
        for (int x = 0; x < res; x++)
        {
            float u = x / (res - 1f), v = y / (res - 1f);
            float dc = new Vector2(u - 0.5f, v - 0.5f).magnitude * 2f;
            float hills = Mathf.PerlinNoise(3.1f + u * 4f, 7.7f + v * 4f) * 0.45f + Mathf.PerlinNoise(u * 14f, v * 14f) * 0.08f;
            float flat = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(0.12f, 0.4f, dc));
            float rim = Mathf.Pow(Mathf.Max(0f, dc - 0.75f) / 0.3f, 2f) * 0.5f;
            h[y, x] = 0.08f + hills * flat + rim;
        }
        td.SetHeights(0, 0, h);

        td.terrainLayers = new[]
        {
            Layer("P3_Grass", NoiseTexture("P3_GrassTex", new Color(0.22f, 0.42f, 0.15f), new Color(0.38f, 0.58f, 0.22f), 6f)),
            Layer("P3_Rock", NoiseTexture("P3_RockTex", new Color(0.38f, 0.36f, 0.34f), new Color(0.6f, 0.58f, 0.55f), 8f)),
            Layer("P3_Dirt", NoiseTexture("P3_DirtTex", new Color(0.45f, 0.33f, 0.2f), new Color(0.62f, 0.5f, 0.33f), 5f)),
        };
        const int ar = 128;
        td.alphamapResolution = ar;
        var alpha = new float[ar, ar, 3];
        for (int y = 0; y < ar; y++)
        for (int x = 0; x < ar; x++)
        {
            float u = x / (ar - 1f), v = y / (ar - 1f);
            float steep = td.GetSteepness(u, v);
            float height = td.GetInterpolatedHeight(u, v);
            float dc = new Vector2(u - 0.5f, v - 0.5f).magnitude * 2f;
            float rock = Mathf.Clamp01((steep - 18f) / 12f) + Mathf.Clamp01((height - 13f) / 4f);
            float dirt = dc < 0.1f ? 1f : Mathf.Clamp01((0.14f - dc) / 0.04f);
            rock = Mathf.Clamp01(rock);
            dirt = Mathf.Clamp01(dirt) * (1f - rock);
            alpha[y, x, 0] = Mathf.Clamp01(1f - rock - dirt);
            alpha[y, x, 1] = rock;
            alpha[y, x, 2] = dirt;
        }
        td.SetAlphamaps(0, 0, alpha);

        td.treePrototypes = new[] { new TreePrototype { prefab = TreePrefab() } };
        Random.InitState(42);
        var trees = new List<TreeInstance>();
        for (int i = 0; i < 2000 && trees.Count < 300; i++)
        {
            float u = Random.Range(0.04f, 0.96f), v = Random.Range(0.04f, 0.96f);
            float dc = new Vector2(u - 0.5f, v - 0.5f).magnitude * 2f;
            if (dc < 0.2f || td.GetSteepness(u, v) > 22f) continue;
            float s = Random.Range(0.8f, 1.4f);
            trees.Add(new TreeInstance
            {
                position = new Vector3(u, td.GetInterpolatedHeight(u, v) / td.size.y, v),
                prototypeIndex = 0,
                widthScale = s,
                heightScale = s * Random.Range(0.9f, 1.2f),
                rotation = Random.Range(0f, Mathf.PI * 2f),
                color = Color.white,
                lightmapColor = Color.white,
            });
        }
        td.SetTreeInstances(trees.ToArray(), true);
        AssetDatabase.CreateAsset(td, $"{gen}/P3_Terrain.asset");
        var terrain = Terrain.CreateTerrainGameObject(td);
        terrain.name = "Terrain";
        terrain.transform.position = new Vector3(-100f, 0f, -100f);

        Object.DestroyImmediate(GameObject.Find("Main Camera"));
        var player = new GameObject("First Person Controller");
        player.transform.position = new Vector3(0f, 2.3f, -3f);
        var cc = player.AddComponent<CharacterController>();
        cc.height = 1.8f;
        cc.radius = 0.4f;
        cc.center = new Vector3(0f, 0.9f, 0f);
        var camGo = new GameObject("FPC Camera");
        camGo.tag = "MainCamera";
        camGo.transform.SetParent(player.transform, false);
        camGo.transform.localPosition = new Vector3(0f, 1.6f, 0f);
        var cam = camGo.AddComponent<Camera>();
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 400f;
        camGo.AddComponent<AudioListener>();
        player.AddComponent<P3Player>().cameraPivot = camGo.transform;

        var windGo = new GameObject("Wind Zone");
        windGo.transform.eulerAngles = new Vector3(0f, 60f, 0f);
        var wind = windGo.AddComponent<WindZone>();
        wind.mode = WindZoneMode.Directional;
        wind.windMain = 1.5f;
        wind.windTurbulence = 0.6f;
        wind.windPulseMagnitude = 0.5f;
        wind.windPulseFrequency = 0.1f;

        var weather = new GameObject("Weather").AddComponent<P3Weather>();
        weather.rain = Weather("Rain", player.transform, false);
        weather.snow = Weather("Snow", player.transform, true);
        weather.wind = wind;

        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.ExponentialSquared;
        RenderSettings.fogColor = new Color(0.62f, 0.66f, 0.7f);
        RenderSettings.fogDensity = 0.008f;
    }

    static void BuildP4()
    {
        new GameObject("Raycaster").AddComponent<P4Raycaster>();
    }

    static void BuildP5()
    {
        new GameObject("Marker AR").AddComponent<P5MarkerAR>();
    }
}
