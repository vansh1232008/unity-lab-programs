using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;

[InitializeOnLoad]
public static class ProgramScenes
{
    const string Root = "Assets/Programs";
    static string gen = "Assets/Programs";
    static readonly string[] Names = { "P1", "P2", "P3", "P4", "P5" };

    static ProgramScenes()
    {
        EditorApplication.delayCall += AutoBuild;
    }

    static void AutoBuild()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
        {
            EditorApplication.playModeStateChanged -= OnPlayMode;
            EditorApplication.playModeStateChanged += OnPlayMode;
            return;
        }
        if (EditorApplication.isCompiling || EditorApplication.isUpdating)
        {
            EditorApplication.delayCall += AutoBuild;
            return;
        }
        bool missing = false;
        foreach (var n in Names)
            if (!File.Exists(ScenePath(n))) missing = true;
        if (!missing) return;
        for (int i = 0; i < SceneManager.sceneCount; i++)
            if (SceneManager.GetSceneAt(i).isDirty)
            {
                Debug.LogWarning("[Programs] Save your open scene, then use the menu Programs > Rebuild All Program Scenes.");
                return;
            }
        Build(false);
    }

    static void OnPlayMode(PlayModeStateChange change)
    {
        if (change != PlayModeStateChange.EnteredEditMode) return;
        EditorApplication.playModeStateChanged -= OnPlayMode;
        EditorApplication.delayCall += AutoBuild;
    }

    [MenuItem("Programs/Rebuild All Program Scenes")]
    static void RebuildAll()
    {
        if (EditorApplication.isPlaying)
        {
            EditorUtility.DisplayDialog("Programs", "Stop Play mode first, then run this again.", "OK");
            return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Build(true);
    }

    public static void BuildFromCommandLine()
    {
        Build(true);
    }

    static string ScenePath(string n) => $"{Root}/{n}/{n}.unity";

    static void Build(bool force)
    {
        string previous = SceneManager.GetActiveScene().path;
        var builders = new Action[] { BuildP1, BuildP2, BuildP3, BuildP4, BuildP5 };
        for (int i = 0; i < Names.Length; i++)
        {
            string path = ScenePath(Names[i]);
            if (!force && File.Exists(path)) continue;
            string folder = $"{Root}/{Names[i]}";
            if (!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder(Root, Names[i]);
            gen = folder + "/Generated";
            if (i < 4 && !AssetDatabase.IsValidFolder(gen)) AssetDatabase.CreateFolder(folder, "Generated");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            builders[i]();
            EditorSceneManager.SaveScene(scene, path);
            Debug.Log("[Programs] Created " + path);
        }
        WriteMarkerPng();
        var list = new List<EditorBuildSettingsScene>();
        foreach (var n in Names) list.Add(new EditorBuildSettingsScene(ScenePath(n), true));
        foreach (var s in EditorBuildSettings.scenes)
            if (!list.Exists(x => x.path == s.path) && File.Exists(s.path)) list.Add(s);
        EditorBuildSettings.scenes = list.ToArray();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorSceneManager.OpenScene(string.IsNullOrEmpty(previous) || !File.Exists(previous) ? ScenePath("P1") : previous);
    }

    static void WriteMarkerPng()
    {
        string path = Root + "/P5/P5_PrintThisMarker.png";
        File.WriteAllBytes(path, MarkerDictionary.CreateTexture(0, 60, 1).EncodeToPNG());
        AssetDatabase.ImportAsset(path);
    }

    static Material Mat(string name, Color c)
    {
        string path = $"{gen}/{name}.mat";
        var m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m == null)
        {
            m = new Material(Shader.Find("Standard"));
            AssetDatabase.CreateAsset(m, path);
        }
        m.shader = Shader.Find("Standard");
        m.color = c;
        EditorUtility.SetDirty(m);
        return m;
    }

    static GameObject Prim(PrimitiveType type, string name, Transform parent, Vector3 pos, Vector3 scale, Material m)
    {
        var go = GameObject.CreatePrimitive(type);
        go.name = name;
        if (parent != null) go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = m;
        return go;
    }

    static Camera MainCam()
    {
        var go = GameObject.Find("Main Camera");
        return go != null ? go.GetComponent<Camera>() : null;
    }

    static void PlaceCamera(Vector3 pos, Vector3 lookAt)
    {
        var cam = MainCam();
        cam.transform.position = pos;
        cam.transform.LookAt(lookAt);
    }

    static void BuildP1()
    {
        Prim(PrimitiveType.Plane, "Plane", null, Vector3.zero, new Vector3(2f, 1f, 2f), Mat("Plane", new Color(0.45f, 0.65f, 0.4f)));
        var cube = Prim(PrimitiveType.Cube, "Cube", null, new Vector3(-2f, 0.5f, 0f), Vector3.one, Mat("Cube", new Color(0.25f, 0.5f, 0.95f)));
        var sphere = Prim(PrimitiveType.Sphere, "Sphere", null, new Vector3(2f, 0.5f, 0f), Vector3.one, Mat("Sphere", new Color(0.95f, 0.3f, 0.3f)));
        cube.AddComponent<geoTransform>().speed = 3f;
        sphere.AddComponent<geoTransform>().speed = 6f;
        PlaceCamera(new Vector3(0f, 6f, -10f), new Vector3(0f, 0.5f, 0f));
    }

    static Font UIFont()
    {
#if UNITY_2022_2_OR_NEWER
        return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
    }

    static RectTransform UIRect(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        var rt = (RectTransform)go.transform;
        rt.anchorMin = rt.anchorMax = anchor;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return rt;
    }

    static Image UIImage(RectTransform rt, string sprite, Color color)
    {
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>(sprite);
        img.type = Image.Type.Sliced;
        img.color = color;
        return img;
    }

    static Text UIText(Transform parent, string text, int size, Color color)
    {
        var rt = UIRect("Text", parent, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        var t = rt.gameObject.AddComponent<Text>();
        t.font = UIFont();
        t.text = text;
        t.fontSize = size;
        t.fontStyle = FontStyle.Bold;
        t.alignment = TextAnchor.MiddleCenter;
        t.color = color;
        return t;
    }

    static Button UIButton(string name, Transform parent, Vector2 anchor, Vector2 pos, string label)
    {
        var b = UIRect(name, parent, anchor, pos, new Vector2(260, 90));
        var img = UIImage(b, "UI/Skin/UISprite.psd", Color.white);
        var button = b.gameObject.AddComponent<Button>();
        button.targetGraphic = img;
        UIText(b, label, 36, new Color(0.15f, 0.15f, 0.2f));
        return button;
    }

    static void BuildP2()
    {
        Prim(PrimitiveType.Plane, "Plane", null, Vector3.zero, new Vector3(2f, 1f, 2f), Mat("Ground", new Color(0.45f, 0.5f, 0.55f)));
        var screenMat = new Material(Shader.Find("Unlit/Texture"));
        AssetDatabase.CreateAsset(screenMat, $"{gen}/ScreenMaterial.mat");
        var screen = GameObject.CreatePrimitive(PrimitiveType.Quad);
        screen.name = "Screen";
        screen.transform.position = new Vector3(0f, 2.2f, 3f);
        screen.transform.localScale = new Vector3(6.4f, 3.6f, 1f);
        var screenRenderer = screen.GetComponent<Renderer>();
        screenRenderer.sharedMaterial = screenMat;
        var vp = screen.AddComponent<UnityEngine.Video.VideoPlayer>();
        vp.clip = AssetDatabase.LoadAssetAtPath<UnityEngine.Video.VideoClip>(Root + "/P2/Prog2Video.mp4");
        vp.playOnAwake = false;
        vp.isLooping = true;
        vp.renderMode = UnityEngine.Video.VideoRenderMode.MaterialOverride;
        vp.targetMaterialRenderer = screenRenderer;
        vp.targetMaterialProperty = "_MainTex";
        vp.audioOutputMode = UnityEngine.Video.VideoAudioOutputMode.None;
        PlaceCamera(new Vector3(0f, 2.2f, -4.5f), new Vector3(0f, 2f, 3f));

        var canvasGo = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        canvasGo.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 1f;
        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        var statusBox = UIRect("Status Image", canvasGo.transform, new Vector2(0.5f, 1f), new Vector2(0, -60), new Vector2(560, 80));
        UIImage(statusBox, "UI/Skin/Background.psd", new Color(0.1f, 0.12f, 0.18f, 0.85f));
        var status = UIText(statusBox, "Video: Stopped", 36, new Color(1f, 0.9f, 0.4f));

        var controller = new GameObject("VideoController").AddComponent<VideoController>();
        controller.videoPlayer = vp;
        controller.status = status;

        var play = UIButton("Play Button", canvasGo.transform, new Vector2(0.5f, 0f), new Vector2(-150, 80), "Play");
        var pause = UIButton("Pause Button", canvasGo.transform, new Vector2(0.5f, 0f), new Vector2(150, 80), "Pause");
        UnityEventTools.AddPersistentListener(play.onClick, new UnityAction(controller.PlayVideo));
        UnityEventTools.AddPersistentListener(pause.onClick, new UnityAction(controller.PauseVideo));
    }

    static Texture2D NoiseTexture(string name, Color a, Color b, float scale)
    {
        int n = 128;
        var tex = new Texture2D(n, n, TextureFormat.RGBA32, true);
        var px = new Color[n * n];
        float ox = Random.Range(0f, 100f), oy = Random.Range(0f, 100f);
        for (int y = 0; y < n; y++)
        for (int x = 0; x < n; x++)
        {
            float u = x / (float)n, v = y / (float)n;
            float f = 0.6f * Tile(u, v, scale, ox, oy) + 0.4f * Tile(u, v, scale * 4f, ox + 33f, oy + 17f);
            px[y * n + x] = Color.Lerp(a, b, f);
        }
        tex.SetPixels(px);
        tex.Apply();
        tex.name = name;
        AssetDatabase.CreateAsset(tex, $"{gen}/{name}.asset");
        return tex;
    }

    static float Tile(float u, float v, float s, float ox, float oy)
    {
        float a = Mathf.PerlinNoise(ox + u * s, oy + v * s);
        float b = Mathf.PerlinNoise(ox + (u - 1f) * s, oy + v * s);
        float c = Mathf.PerlinNoise(ox + u * s, oy + (v - 1f) * s);
        float d = Mathf.PerlinNoise(ox + (u - 1f) * s, oy + (v - 1f) * s);
        return Mathf.Lerp(Mathf.Lerp(a, b, u), Mathf.Lerp(c, d, u), v);
    }

    static TerrainLayer Layer(string name, Texture2D tex)
    {
        var l = new TerrainLayer { diffuseTexture = tex, tileSize = new Vector2(6f, 6f) };
        AssetDatabase.CreateAsset(l, $"{gen}/{name}.terrainlayer");
        return l;
    }

    static GameObject TreePrefab()
    {
        var temp = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        var trunkMesh = temp.GetComponent<MeshFilter>().sharedMesh;
        Object.DestroyImmediate(temp);
        temp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        var leafMesh = temp.GetComponent<MeshFilter>().sharedMesh;
        Object.DestroyImmediate(temp);
        var trunk = new Mesh();
        trunk.CombineMeshes(new[] { new CombineInstance { mesh = trunkMesh, transform = Matrix4x4.TRS(new Vector3(0f, 1.5f, 0f), Quaternion.identity, new Vector3(0.35f, 1.5f, 0.35f)) } }, true, true);
        var leaves = new Mesh();
        leaves.CombineMeshes(new[] { new CombineInstance { mesh = leafMesh, transform = Matrix4x4.TRS(new Vector3(0f, 3.6f, 0f), Quaternion.identity, new Vector3(2.6f, 2.4f, 2.6f)) } }, true, true);
        var mesh = new Mesh { name = "TreeMesh" };
        mesh.CombineMeshes(new[] { new CombineInstance { mesh = trunk }, new CombineInstance { mesh = leaves } }, false, false);
        mesh.RecalculateBounds();
        AssetDatabase.CreateAsset(mesh, $"{gen}/TreeMesh.asset");
        var go = new GameObject("Tree");
        go.AddComponent<MeshFilter>().sharedMesh = mesh;
        var bark = Mat("Bark", new Color(0.4f, 0.27f, 0.15f));
        bark.shader = Shader.Find("Nature/Tree Soft Occlusion Bark");
        bark.color = new Color(0.4f, 0.27f, 0.15f);
        var leafMat = Mat("Leaves", new Color(0.2f, 0.5f, 0.18f));
        leafMat.shader = Shader.Find("Nature/Tree Soft Occlusion Leaves");
        leafMat.color = new Color(0.2f, 0.5f, 0.18f);
        go.AddComponent<MeshRenderer>().sharedMaterials = new[] { bark, leafMat };
        var col = go.AddComponent<CapsuleCollider>();
        col.radius = 0.35f;
        col.height = 3f;
        col.center = new Vector3(0f, 1.5f, 0f);
        var prefab = PrefabUtility.SaveAsPrefabAsset(go, $"{gen}/Tree.prefab");
        Object.DestroyImmediate(go);
        return prefab;
    }

    static GameObject Particles(string name, Transform parent, bool snow)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = new Vector3(0f, snow ? 10f : 12f, 0f);
        go.transform.localEulerAngles = new Vector3(90f, 0f, 0f);
        var ps = go.AddComponent<ParticleSystem>();
        ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        var main = ps.main;
        main.loop = true;
        main.playOnAwake = true;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = snow ? 4000 : 6000;
        main.startLifetime = snow ? 7f : 1.2f;
        main.startSpeed = snow ? 1.5f : 14f;
        main.startSize = snow ? 0.12f : 0.04f;
        main.gravityModifier = snow ? 0.04f : 1f;
        main.startColor = snow ? new Color(1f, 1f, 1f, 0.9f) : new Color(0.75f, 0.82f, 1f, 0.55f);
        var em = ps.emission;
        em.rateOverTime = snow ? 500f : 2500f;
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Box;
        shape.scale = new Vector3(40f, 40f, 1f);
        var ext = ps.externalForces;
        ext.enabled = true;
        ext.multiplier = snow ? 3f : 1.5f;
        var r = go.GetComponent<ParticleSystemRenderer>();
        r.sharedMaterial = AssetDatabase.GetBuiltinExtraResource<Material>("Default-ParticleSystem.mat");
        if (!snow)
        {
            r.renderMode = ParticleSystemRenderMode.Stretch;
            r.lengthScale = 1f;
            r.velocityScale = 0.06f;
        }
        return go;
    }

    static void BuildP3()
    {
        const int res = 257;
        var td = new TerrainData { heightmapResolution = res };
        td.size = new Vector3(200f, 25f, 200f);
        var h = new float[res, res];
        for (int y = 0; y < res; y++)
        for (int x = 0; x < res; x++)
        {
            float u = x / (res - 1f), v = y / (res - 1f);
            float dc = new Vector2(u - 0.5f, v - 0.5f).magnitude * 2f;
            float hills = Mathf.PerlinNoise(3.1f + u * 4f, 7.7f + v * 4f) * 0.45f + Mathf.PerlinNoise(u * 14f, v * 14f) * 0.08f;
            float flat = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(0.12f, 0.4f, dc));
            float rim = Mathf.Pow(Mathf.Max(0f, dc - 0.75f) / 0.3f, 2f) * 0.5f;
            h[y, x] = 0.08f + hills * flat + rim;
        }
        td.SetHeights(0, 0, h);

        td.terrainLayers = new[]
        {
            Layer("Grass", NoiseTexture("GrassTexture", new Color(0.22f, 0.42f, 0.15f), new Color(0.38f, 0.58f, 0.22f), 6f)),
            Layer("Rock", NoiseTexture("RockTexture", new Color(0.38f, 0.36f, 0.34f), new Color(0.6f, 0.58f, 0.55f), 8f)),
            Layer("Dirt", NoiseTexture("DirtTexture", new Color(0.45f, 0.33f, 0.2f), new Color(0.62f, 0.5f, 0.33f), 5f)),
        };
        const int ar = 128;
        td.alphamapResolution = ar;
        var alpha = new float[ar, ar, 3];
        for (int y = 0; y < ar; y++)
        for (int x = 0; x < ar; x++)
        {
            float u = x / (ar - 1f), v = y / (ar - 1f);
            float steep = td.GetSteepness(u, v);
            float height = td.GetInterpolatedHeight(u, v);
            float dc = new Vector2(u - 0.5f, v - 0.5f).magnitude * 2f;
            float rock = Mathf.Clamp01(Mathf.Clamp01((steep - 18f) / 12f) + Mathf.Clamp01((height - 13f) / 4f));
            float dirt = Mathf.Clamp01(dc < 0.1f ? 1f : (0.14f - dc) / 0.04f) * (1f - rock);
            alpha[y, x, 0] = Mathf.Clamp01(1f - rock - dirt);
            alpha[y, x, 1] = rock;
            alpha[y, x, 2] = dirt;
        }
        td.SetAlphamaps(0, 0, alpha);

        td.treePrototypes = new[] { new TreePrototype { prefab = TreePrefab() } };
        Random.InitState(42);
        var trees = new List<TreeInstance>();
        for (int i = 0; i < 2000 && trees.Count < 300; i++)
        {
            float u = Random.Range(0.04f, 0.96f), v = Random.Range(0.04f, 0.96f);
            float dc = new Vector2(u - 0.5f, v - 0.5f).magnitude * 2f;
            if (dc < 0.2f || td.GetSteepness(u, v) > 22f) continue;
            float s = Random.Range(0.8f, 1.4f);
            trees.Add(new TreeInstance
            {
                position = new Vector3(u, td.GetInterpolatedHeight(u, v) / td.size.y, v),
                prototypeIndex = 0,
                widthScale = s,
                heightScale = s * Random.Range(0.9f, 1.2f),
                rotation = Random.Range(0f, Mathf.PI * 2f),
                color = Color.white,
                lightmapColor = Color.white,
            });
        }
        td.SetTreeInstances(trees.ToArray(), true);
        AssetDatabase.CreateAsset(td, $"{gen}/Terrain.asset");
        var terrain = Terrain.CreateTerrainGameObject(td);
        terrain.name = "Terrain";
        terrain.transform.position = new Vector3(-100f, 0f, -100f);

        Object.DestroyImmediate(GameObject.Find("Main Camera"));
        var player = new GameObject("FPC");
        player.transform.position = new Vector3(0f, 2.3f, -3f);
        var cc = player.AddComponent<CharacterController>();
        cc.height = 1.8f;
        cc.radius = 0.4f;
        cc.center = new Vector3(0f, 0.9f, 0f);
        var camGo = new GameObject("FPC Camera");
        camGo.tag = "MainCamera";
        camGo.transform.SetParent(player.transform, false);
        camGo.transform.localPosition = new Vector3(0f, 1.6f, 0f);
        var cam = camGo.AddComponent<Camera>();
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 400f;
        camGo.AddComponent<AudioListener>();
        player.AddComponent<FPController>().cam = camGo.transform;

        var windGo = new GameObject("Wind Zone");
        windGo.transform.eulerAngles = new Vector3(0f, 60f, 0f);
        var wind = windGo.AddComponent<WindZone>();
        wind.mode = WindZoneMode.Directional;
        wind.windMain = 1.5f;
        wind.windTurbulence = 0.6f;
        wind.windPulseMagnitude = 0.5f;
        wind.windPulseFrequency = 0.1f;

        Particles("Rain", player.transform, false);
        Particles("Snow", player.transform, true).SetActive(false);
    }

    static Sprite MakeSprite(string name, int w, int h, Func<float, float, bool> inside)
    {
        var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
        var px = new Color32[w * h];
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
            px[y * w + x] = inside((x + 0.5f) / w, (y + 0.5f) / h) ? new Color32(255, 255, 255, 255) : new Color32(255, 255, 255, 0);
        tex.SetPixels32(px);
        tex.Apply();
        string path = $"{gen}/{name}.png";
        File.WriteAllBytes(path, tex.EncodeToPNG());
        Object.DestroyImmediate(tex);
        AssetDatabase.ImportAsset(path);
        var importer = (TextureImporter)AssetImporter.GetAtPath(path);
        importer.textureType = TextureImporterType.Sprite;
        importer.spriteImportMode = SpriteImportMode.Single;
        importer.spritePixelsPerUnit = w;
        importer.alphaIsTransparency = true;
        importer.SaveAndReimport();
        return AssetDatabase.LoadAssetAtPath<Sprite>(path);
    }

    static GameObject SpriteObject(string name, Transform parent, Sprite sprite, Vector2 pos, Vector2 scale, Color color, int order)
    {
        var go = new GameObject(name);
        if (parent != null) go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = new Vector3(scale.x, scale.y, 1f);
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.color = color;
        sr.sortingOrder = order;
        return go;
    }

    static void BuildP4()
    {
        var square = MakeSprite("Square", 32, 32, (u, v) => true);
        var circle = MakeSprite("Circle", 64, 64, (u, v) => (u - 0.5f) * (u - 0.5f) + (v - 0.5f) * (v - 0.5f) <= 0.25f);
        var diamond = MakeSprite("Diamond", 64, 64, (u, v) => Mathf.Abs(u - 0.5f) + Mathf.Abs(v - 0.5f) <= 0.5f);

        var cam = MainCam();
        cam.orthographic = true;
        cam.orthographicSize = 5f;
        cam.transform.position = new Vector3(0f, 0f, -10f);
        cam.transform.rotation = Quaternion.identity;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.12f, 0.14f, 0.2f);
        Object.DestroyImmediate(GameObject.Find("Directional Light"));

        var sq = SpriteObject("Square", null, square, new Vector2(3f, 2.5f), new Vector2(1.6f, 1.6f), Color.red, 1);
        sq.AddComponent<BoxCollider2D>();
        var ci = SpriteObject("Circle", null, circle, new Vector2(5f, -1.5f), new Vector2(1.8f, 1.8f), Color.red, 1);
        ci.AddComponent<CircleCollider2D>();
        var di = SpriteObject("Diamond", null, diamond, new Vector2(0.5f, -3f), new Vector2(1.8f, 1.8f), Color.red, 1);
        di.AddComponent<PolygonCollider2D>();

        var shooter = SpriteObject("Ray Origin", null, circle, new Vector2(-6.5f, 0f), new Vector2(0.8f, 0.8f), new Color(0.3f, 0.7f, 1f), 2);
        var line = shooter.AddComponent<LineRenderer>();
        var lineMat = new Material(Shader.Find("Sprites/Default"));
        AssetDatabase.CreateAsset(lineMat, $"{gen}/RayLine.mat");
        line.sharedMaterial = lineMat;
        line.positionCount = 2;
        line.useWorldSpace = true;
        line.startWidth = line.endWidth = 0.06f;
        line.startColor = line.endColor = new Color(1f, 0.9f, 0.2f);
        line.sortingOrder = 3;
        var rc = shooter.AddComponent<RayCast2D>();
        rc.line = line;
    }

    static void BuildP5()
    {
        new GameObject("Marker AR").AddComponent<P5MarkerAR>();
    }
}
