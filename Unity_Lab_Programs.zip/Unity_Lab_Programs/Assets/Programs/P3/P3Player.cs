using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class P3Player : MonoBehaviour
{
    public Transform cameraPivot;
    public float walkSpeed = 4f;
    public float runSpeed = 9f;
    public float jumpHeight = 1.3f;
    public float mouseSensitivity = 2.5f;
    public float gravity = 18f;

    CharacterController controller;
    float pitch, verticalSpeed;

    void Start()
    {
        controller = GetComponent<CharacterController>();
        Lock(true);
    }

    void Lock(bool on)
    {
        Cursor.lockState = on ? CursorLockMode.Locked : CursorLockMode.None;
        Cursor.visible = !on;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) Lock(false);
        if (Input.GetMouseButtonDown(0)) Lock(true);

        if (Cursor.lockState == CursorLockMode.Locked)
        {
            transform.Rotate(0f, Input.GetAxis("Mouse X") * mouseSensitivity, 0f);
            pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * mouseSensitivity, -80f, 80f);
            cameraPivot.localEulerAngles = new Vector3(pitch, 0f, 0f);
        }

        Vector3 move = transform.right * Input.GetAxis("Horizontal") + transform.forward * Input.GetAxis("Vertical");
        float speed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed;
        if (controller.isGrounded)
        {
            verticalSpeed = -1f;
            if (Input.GetKeyDown(KeyCode.Space)) verticalSpeed = Mathf.Sqrt(2f * gravity * jumpHeight);
        }
        verticalSpeed -= gravity * Time.deltaTime;
        controller.Move((Vector3.ClampMagnitude(move, 1f) * speed + Vector3.up * verticalSpeed) * Time.deltaTime);
    }
}
