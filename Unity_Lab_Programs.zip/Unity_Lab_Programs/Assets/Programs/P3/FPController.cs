using UnityEngine;

public class FPController : MonoBehaviour
{
    public float speed = 5f;
    public float mouseSpeed = 2f;
    public Transform cam;
    CharacterController cc;
    float pitch;

    void Start()
    {
        cc = GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        transform.Rotate(0, Input.GetAxis("Mouse X") * mouseSpeed, 0);
        pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * mouseSpeed, -80f, 80f);
        cam.localEulerAngles = new Vector3(pitch, 0, 0);

        Vector3 move = transform.right * Input.GetAxis("Horizontal") + transform.forward * Input.GetAxis("Vertical");
        cc.SimpleMove(move * speed);
    }
}
