using UnityEngine;

public class P3Weather : MonoBehaviour
{
    public ParticleSystem rain;
    public ParticleSystem snow;
    public WindZone wind;

    void Start()
    {
        rain.Play();
        snow.Stop();
    }

    void Toggle(ParticleSystem ps)
    {
        if (ps.isPlaying) ps.Stop(true, ParticleSystemStopBehavior.StopEmitting);
        else ps.Play();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R)) Toggle(rain);
        if (Input.GetKeyDown(KeyCode.N)) Toggle(snow);
        if (Input.GetKey(KeyCode.Equals) || Input.GetKey(KeyCode.KeypadPlus)) wind.windMain = Mathf.Min(10f, wind.windMain + 3f * Time.deltaTime);
        if (Input.GetKey(KeyCode.Minus) || Input.GetKey(KeyCode.KeypadMinus)) wind.windMain = Mathf.Max(0f, wind.windMain - 3f * Time.deltaTime);
        if (Input.GetKey(KeyCode.LeftBracket)) wind.transform.Rotate(0f, -60f * Time.deltaTime, 0f, Space.World);
        if (Input.GetKey(KeyCode.RightBracket)) wind.transform.Rotate(0f, 60f * Time.deltaTime, 0f, Space.World);
    }

    void OnGUI()
    {
        GUI.Box(new Rect(10, 10, 420, 205),
            "PROGRAM 3 - First Person Controller\n\n" +
            $"Wind strength: {wind.windMain:0.0}    Wind direction: {wind.transform.eulerAngles.y:0} deg\n" +
            $"Rain: {(rain.isEmitting ? "ON" : "OFF")}    Snow: {(snow.isEmitting ? "ON" : "OFF")}\n\n" +
            "Mouse = look,  W A S D = walk,  Shift = run,  Space = jump\n" +
            "R = rain on/off,  N = snow on/off\n" +
            "+ / - = wind strength,  [ / ] = wind direction\n" +
            "Esc = free the mouse,  click = capture it again");
    }
}
