using UnityEngine;

public class geoTransform : MonoBehaviour
{
    public float moveSpeed = 3f;
    public float rotateSpeed = 90f;
    public float scaleSpeed = 1f;
    public bool startSelected = false;

    static geoTransform selected;
    Renderer rend;
    Color originalColor;
    Vector3 startPos, startScale;
    Quaternion startRot;

    void Start()
    {
        rend = GetComponent<Renderer>();
        originalColor = rend.material.color;
        startPos = transform.position;
        startRot = transform.rotation;
        startScale = transform.localScale;
        if (startSelected) selected = this;
    }

    void OnMouseDown()
    {
        selected = this;
    }

    void Update()
    {
        rend.material.color = selected == this ? Color.yellow : originalColor;
        if (selected != this) return;

        if (Input.GetKeyDown(KeyCode.Alpha1)) moveSpeed = 1f;
        if (Input.GetKeyDown(KeyCode.Alpha2)) moveSpeed = 3f;
        if (Input.GetKeyDown(KeyCode.Alpha3)) moveSpeed = 8f;
        float factor = 1f;
        if (Input.GetKey(KeyCode.LeftShift)) factor = 3f;
        if (Input.GetKey(KeyCode.LeftControl)) factor = 0.3f;
        float dt = Time.deltaTime * factor;

        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0f, Input.GetAxis("Vertical"));
        if (Input.GetKey(KeyCode.E)) move.y += 1f;
        if (Input.GetKey(KeyCode.Q)) move.y -= 1f;
        transform.Translate(move * moveSpeed * dt, Space.World);

        float dir = Input.GetKey(KeyCode.R) ? -1f : 1f;
        if (Input.GetKey(KeyCode.X)) transform.Rotate(Vector3.right * rotateSpeed * dir * dt, Space.World);
        if (Input.GetKey(KeyCode.Y)) transform.Rotate(Vector3.up * rotateSpeed * dir * dt, Space.World);
        if (Input.GetKey(KeyCode.Z)) transform.Rotate(Vector3.forward * rotateSpeed * dir * dt, Space.World);
        if (Input.GetMouseButton(1))
        {
            transform.Rotate(Vector3.up, -Input.GetAxis("Mouse X") * 5f, Space.World);
            transform.Rotate(Vector3.right, Input.GetAxis("Mouse Y") * 5f, Space.World);
        }

        Vector3 s = Vector3.zero;
        if (Input.GetKey(KeyCode.L)) s.x += 1f;
        if (Input.GetKey(KeyCode.J)) s.x -= 1f;
        if (Input.GetKey(KeyCode.I)) s.y += 1f;
        if (Input.GetKey(KeyCode.K)) s.y -= 1f;
        if (Input.GetKey(KeyCode.O)) s.z += 1f;
        if (Input.GetKey(KeyCode.U)) s.z -= 1f;
        if (Input.GetKey(KeyCode.Equals) || Input.GetKey(KeyCode.KeypadPlus)) s += Vector3.one;
        if (Input.GetKey(KeyCode.Minus) || Input.GetKey(KeyCode.KeypadMinus)) s -= Vector3.one;
        Vector3 newScale = transform.localScale + s * scaleSpeed * dt + Vector3.one * Input.mouseScrollDelta.y * 0.1f;
        transform.localScale = Vector3.Max(newScale, Vector3.one * 0.1f);

        if (Input.GetKeyDown(KeyCode.Space))
        {
            transform.position = startPos;
            transform.rotation = startRot;
            transform.localScale = startScale;
        }
    }

    void OnGUI()
    {
        if (!startSelected) return;
        string name = selected != null ? selected.name : "none";
        GUI.Box(new Rect(10, 10, 430, 190),
            "PROGRAM 1 - geoTransform        Selected: " + name + "\n\n" +
            "Click an object to select it\n" +
            "Move:    W A S D / arrows,  Q / E = down / up\n" +
            "Speed:   1 / 2 / 3,  hold Shift = faster,  Ctrl = slower\n" +
            "Rotate:  hold X / Y / Z  (R = reverse),  right-mouse drag\n" +
            "Scale:   J / L (X),  K / I (Y),  U / O (Z),  + / - or mouse wheel\n" +
            "Reset:   Space");
    }
}
