using UnityEngine;

public class geoTransform : MonoBehaviour
{
    public float speed = 5f;

    void Update()
    {
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        transform.Translate(x * speed * Time.deltaTime, 0, z * speed * Time.deltaTime, Space.World);

        if (Input.GetKey(KeyCode.X)) transform.Rotate(90 * Time.deltaTime, 0, 0);
        if (Input.GetKey(KeyCode.Y)) transform.Rotate(0, 90 * Time.deltaTime, 0);
        if (Input.GetKey(KeyCode.Z)) transform.Rotate(0, 0, 90 * Time.deltaTime);

        if (Input.GetKey(KeyCode.I)) transform.localScale += new Vector3(1, 0, 0) * Time.deltaTime;
        if (Input.GetKey(KeyCode.O)) transform.localScale += new Vector3(0, 1, 0) * Time.deltaTime;
        if (Input.GetKey(KeyCode.P)) transform.localScale += new Vector3(0, 0, 1) * Time.deltaTime;
        if (Input.GetKeyDown(KeyCode.R)) transform.localScale = Vector3.one;
    }
}
