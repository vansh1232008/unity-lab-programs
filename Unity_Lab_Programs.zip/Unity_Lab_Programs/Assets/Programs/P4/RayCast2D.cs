using UnityEngine;

public class RayCast2D : MonoBehaviour
{
    public float rayDistance = 15f;
    public LineRenderer line;
    SpriteRenderer lastHit;

    void Update()
    {
        Vector3 mouse = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 origin = transform.position;
        Vector2 direction = ((Vector2)mouse - origin).normalized;

        RaycastHit2D hit = Physics2D.Raycast(origin, direction, rayDistance);

        if (lastHit != null) lastHit.color = Color.red;
        line.SetPosition(0, origin);

        if (hit.collider != null)
        {
            lastHit = hit.collider.GetComponent<SpriteRenderer>();
            lastHit.color = Color.green;
            line.SetPosition(1, hit.point);
            Debug.Log("Hit: True  Target: " + hit.collider.name + "  Distance: " + hit.distance + "  Position: " + hit.point);
        }
        else
        {
            line.SetPosition(1, origin + direction * rayDistance);
        }
    }
}
