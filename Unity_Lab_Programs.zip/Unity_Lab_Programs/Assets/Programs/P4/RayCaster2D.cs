using UnityEngine;

public class RayCaster2D : MonoBehaviour
{
    public GameObject parachute;
    public float openDistance = 5f;

    void Update()
    {
        Vector2 origin = transform.position + Vector3.down;
        RaycastHit2D hit = Physics2D.Raycast(origin, Vector2.down);
        bool isHit = hit.collider != null;

        if (isHit)
        {
            Debug.DrawRay(origin, Vector2.down * hit.distance, Color.red);
            Debug.Log("Hit: " + isHit + "  Object: " + hit.collider.name + "  Distance: " + hit.distance + "  Position: " + hit.point);
            if (hit.distance < openDistance)
            {
                parachute.SetActive(true);
                GetComponent<Rigidbody2D>().drag = 5f;
            }
        }
    }
}
