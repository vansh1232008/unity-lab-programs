using UnityEngine;

public class RayCaster : MonoBehaviour
{
    public GameObject parachute;
    public float openDistance = 12f;

    void Update()
    {
        RaycastHit hit;
        bool isHit = Physics.Raycast(transform.position, Vector3.down, out hit);

        if (isHit)
        {
            Debug.Log("Hit: " + isHit + "  Distance: " + hit.distance + "  Position: " + hit.point);
            if (hit.distance < openDistance)
            {
                parachute.SetActive(true);
                GetComponent<Rigidbody>().drag = 5f;
            }
        }
    }
}
