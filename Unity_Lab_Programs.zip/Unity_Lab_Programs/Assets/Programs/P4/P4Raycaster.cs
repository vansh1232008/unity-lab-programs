using UnityEngine;

public class P4Raycaster : MonoBehaviour
{
    public float openHeight = 12f;
    public float dropHeight = 45f;

    Camera cam;
    Transform jumper;
    GameObject canopy;
    Rigidbody body;
    LineRenderer clickLine, downLine;
    float clickLineTimer;
    bool parachuteOpen, landed;
    float altitude;
    bool groundBelow;
    string info = "Click any object to fire a ray at it.";
    Renderer lastHit;
    Color lastColor;

    GameObject Make(PrimitiveType type, string name, Vector3 pos, Vector3 scale, Color color)
    {
        var go = GameObject.CreatePrimitive(type);
        go.name = name;
        go.transform.position = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().material.color = color;
        if (type == PrimitiveType.Cylinder)
        {
            DestroyImmediate(go.GetComponent<Collider>());
            go.AddComponent<MeshCollider>();
        }
        return go;
    }

    LineRenderer Line(string name, Color color, float width)
    {
        var lr = new GameObject(name).AddComponent<LineRenderer>();
        lr.material = new Material(Shader.Find("Sprites/Default"));
        lr.startColor = lr.endColor = color;
        lr.startWidth = lr.endWidth = width;
        lr.positionCount = 2;
        return lr;
    }

    void Start()
    {
        cam = Camera.main;
        cam.transform.position = new Vector3(0f, 16f, -30f);
        cam.transform.LookAt(new Vector3(0f, 8f, 4f));

        Make(PrimitiveType.Plane, "Ground", Vector3.zero, new Vector3(8f, 1f, 8f), new Color(0.45f, 0.6f, 0.35f));
        Make(PrimitiveType.Cube, "Red Crate", new Vector3(-9f, 1f, 2f), new Vector3(2f, 2f, 2f), new Color(0.85f, 0.25f, 0.2f));
        Make(PrimitiveType.Sphere, "Blue Ball", new Vector3(9f, 1.5f, 4f), new Vector3(3f, 3f, 3f), new Color(0.25f, 0.45f, 0.9f));
        Make(PrimitiveType.Cylinder, "Yellow Tower", new Vector3(-5f, 4f, 14f), new Vector3(2f, 4f, 2f), new Color(0.95f, 0.8f, 0.2f));
        Make(PrimitiveType.Capsule, "Green Pillar", new Vector3(6f, 2f, 14f), new Vector3(1.5f, 2f, 1.5f), new Color(0.3f, 0.8f, 0.45f));
        var target = Make(PrimitiveType.Cylinder, "Landing Target", new Vector3(0f, 0.02f, 4f), new Vector3(6f, 0.02f, 6f), new Color(1f, 1f, 1f));
        Make(PrimitiveType.Cylinder, "Target Centre", new Vector3(0f, 0.05f, 4f), new Vector3(2.5f, 0.03f, 2.5f), new Color(0.9f, 0.2f, 0.2f));
        Destroy(target.GetComponent<Collider>());

        var j = Make(PrimitiveType.Capsule, "Parachutist", new Vector3(0f, dropHeight, 4f), new Vector3(0.8f, 1f, 0.8f), new Color(0.2f, 0.25f, 0.35f));
        jumper = j.transform;
        body = j.AddComponent<Rigidbody>();
        body.constraints = RigidbodyConstraints.FreezeRotation;
        canopy = Make(PrimitiveType.Sphere, "Parachute", Vector3.zero, new Vector3(5f, 1.4f, 5f), new Color(1f, 0.45f, 0.15f));
        Destroy(canopy.GetComponent<Collider>());
        canopy.transform.SetParent(jumper, false);
        canopy.transform.localPosition = new Vector3(0f, 3.2f, 0f);
        canopy.transform.localScale = new Vector3(6f, 1.6f, 6f);
        canopy.SetActive(false);

        clickLine = Line("Click Ray", new Color(1f, 1f, 0.2f), 0.08f);
        clickLine.enabled = false;
        downLine = Line("Down Ray", new Color(0.2f, 1f, 0.4f), 0.06f);
    }

    void Drop()
    {
        jumper.position = new Vector3(Random.Range(-4f, 4f), dropHeight, Random.Range(1f, 7f));
        body.velocity = Vector3.zero;
        body.drag = 0f;
        parachuteOpen = false;
        landed = false;
        canopy.SetActive(false);
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);
            bool hit = Physics.Raycast(ray, out RaycastHit h, 500f);
            if (lastHit != null) lastHit.material.color = lastColor;
            lastHit = null;
            clickLine.enabled = true;
            clickLineTimer = 1.2f;
            clickLine.SetPosition(0, cam.transform.position + cam.transform.forward * 0.5f - Vector3.up * 0.5f);
            if (hit)
            {
                clickLine.SetPosition(1, h.point);
                info = $"Raycast hit: TRUE\nObject: {h.collider.name}\nDistance: {h.distance:0.00} m\nHit point: ({h.point.x:0.0}, {h.point.y:0.0}, {h.point.z:0.0})\nObject position: {h.transform.position}";
                lastHit = h.collider.GetComponent<Renderer>();
                if (lastHit != null)
                {
                    lastColor = lastHit.material.color;
                    lastHit.material.color = Color.yellow;
                }
            }
            else
            {
                clickLine.SetPosition(1, ray.origin + ray.direction * 200f);
                info = "Raycast hit: FALSE\nThe ray did not hit any object.";
            }
        }
        if (clickLineTimer > 0f)
        {
            clickLineTimer -= Time.deltaTime;
            if (clickLineTimer <= 0f) clickLine.enabled = false;
        }

        Vector3 origin = jumper.position + Vector3.down * 1.05f;
        groundBelow = Physics.Raycast(origin, Vector3.down, out RaycastHit g, 500f);
        altitude = groundBelow ? g.distance : 999f;
        downLine.SetPosition(0, origin);
        downLine.SetPosition(1, groundBelow ? g.point : origin + Vector3.down * 50f);
        downLine.startColor = downLine.endColor = altitude < openHeight ? new Color(1f, 0.3f, 0.2f) : new Color(0.2f, 1f, 0.4f);
        if (!parachuteOpen && groundBelow && altitude < openHeight)
        {
            parachuteOpen = true;
            canopy.SetActive(true);
            body.drag = 3.5f;
        }
        if (parachuteOpen && altitude < 0.15f) landed = true;
        if (Input.GetKeyDown(KeyCode.Space)) Drop();
    }

    void OnGUI()
    {
        GUI.Box(new Rect(10, 10, 420, 150), "PROGRAM 4 - Ray-caster\n\n" + info);
        string state = landed ? "LANDED" : parachuteOpen ? "PARACHUTE OPEN" : "FREE FALL";
        GUI.Box(new Rect(10, 170, 420, 110),
            "Parachutist (downward ray)\n\n" +
            $"Ray hit ground: {groundBelow}    Altitude: {altitude:0.0} m\n" +
            $"Parachute opens below {openHeight:0} m    State: {state}\n" +
            "Space = drop again");
    }
}
