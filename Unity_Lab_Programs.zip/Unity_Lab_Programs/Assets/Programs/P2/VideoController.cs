using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;

public class VideoController : MonoBehaviour
{
    public VideoPlayer videoPlayer;
    public Text status;

    public void PlayVideo()
    {
        videoPlayer.Play();
        status.text = "Video: Playing";
    }

    public void PauseVideo()
    {
        videoPlayer.Pause();
        status.text = "Video: Paused";
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (videoPlayer.isPlaying) PauseVideo();
            else PlayVideo();
        }
    }
}
