using UnityEngine;
using UnityEngine.UI;

public class AnimMenu : MonoBehaviour
{
    public Animator character1;
    public Animator character2;
    public Text message;

    public void Play(string trigger)
    {
        character1.SetTrigger(trigger);
        character2.SetTrigger(trigger);
        message.text = "Trigger: " + trigger;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)) Play("win");
    }
}
