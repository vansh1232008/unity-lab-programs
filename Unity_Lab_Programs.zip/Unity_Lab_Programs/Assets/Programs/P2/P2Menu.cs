using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class P2Menu : MonoBehaviour
{
    public Animator[] characters;

    readonly string[] triggers = { "idle", "walk", "jump", "wave", "dance", "win" };
    readonly string[] labels = { "Idle", "Walk", "Jump", "Wave", "Dance", "Win" };
    readonly Color[] colors =
    {
        new Color(0.55f, 0.6f, 0.68f), new Color(0.3f, 0.65f, 0.95f), new Color(0.95f, 0.65f, 0.2f),
        new Color(0.4f, 0.85f, 0.45f), new Color(0.85f, 0.4f, 0.9f), new Color(1f, 0.82f, 0.2f),
    };
    readonly List<Image> buttonImages = new List<Image>();
    Text message, targetLabel;
    int selected, count, target = 2;
    Font font;
    Sprite rounded, circle, star;

    void Start()
    {
#if UNITY_2022_2_OR_NEWER
        font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        rounded = MakeSprite(64, 14, false, false);
        circle = MakeSprite(64, 32, true, false);
        star = MakeSprite(64, 0, false, true);
        if (FindObjectOfType<EventSystem>() == null)
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        BuildUI();
        Highlight();
    }

    static Sprite MakeSprite(int size, float radius, bool isCircle, bool isStar)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp };
        var px = new Color[size * size];
        float c = size * 0.5f;
        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float dx = x + 0.5f - c, dy = y + 0.5f - c;
            float a;
            if (isStar)
            {
                float ang = Mathf.Atan2(dy, dx);
                float r = Mathf.Sqrt(dx * dx + dy * dy) / c;
                float edge = 0.55f + 0.4f * Mathf.Pow(Mathf.Abs(Mathf.Cos(ang * 2.5f)), 3f);
                a = Mathf.Clamp01((edge - r) * size * 0.5f);
            }
            else if (isCircle)
            {
                a = Mathf.Clamp01(c - Mathf.Sqrt(dx * dx + dy * dy));
            }
            else
            {
                float qx = Mathf.Abs(dx) - (c - radius), qy = Mathf.Abs(dy) - (c - radius);
                float d = new Vector2(Mathf.Max(qx, 0f), Mathf.Max(qy, 0f)).magnitude + Mathf.Min(Mathf.Max(qx, qy), 0f) - radius;
                a = Mathf.Clamp01(0.5f - d);
            }
            px[y * size + x] = new Color(1f, 1f, 1f, a);
        }
        tex.SetPixels(px);
        tex.Apply();
        var border = isStar || isCircle ? Vector4.zero : new Vector4(radius, radius, radius, radius);
        return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, border);
    }

    RectTransform Rect(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        var rt = (RectTransform)go.transform;
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return rt;
    }

    Image AddImage(RectTransform rt, Sprite sprite, Color color)
    {
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = sprite;
        img.type = sprite == rounded ? Image.Type.Sliced : Image.Type.Simple;
        img.color = color;
        return img;
    }

    Text AddText(RectTransform rt, string text, int size, TextAnchor anchor, Color color, FontStyle style = FontStyle.Normal)
    {
        var t = rt.gameObject.AddComponent<Text>();
        t.font = font;
        t.text = text;
        t.fontSize = size;
        t.alignment = anchor;
        t.color = color;
        t.fontStyle = style;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        return t;
    }

    void BuildUI()
    {
        var canvasGo = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGo.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 1f;
        var root = canvasGo.transform;

        var panel = Rect("Menu Panel", root, new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(230, 0), new Vector2(400, 860));
        AddImage(panel, rounded, new Color(0.06f, 0.08f, 0.12f, 0.88f));

        var banner = Rect("Banner Image", panel, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -60), new Vector2(360, 90));
        AddImage(banner, rounded, new Color(0.15f, 0.45f, 0.85f, 1f));
        var bannerStar = Rect("Star Sprite", banner, new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(45, 0), new Vector2(56, 56));
        AddImage(bannerStar, star, new Color(1f, 0.85f, 0.3f));
        AddText(Rect("Title", banner, new Vector2(0f, 0f), new Vector2(1f, 1f), new Vector2(30, 0), new Vector2(-80, 0)),
            "Animation Menu", 32, TextAnchor.MiddleCenter, Color.white, FontStyle.Bold);

        for (int i = 0; i < labels.Length; i++)
        {
            int index = i;
            var b = Rect(labels[i] + " Button", panel, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -160 - i * 92), new Vector2(340, 78));
            var img = AddImage(b, rounded, new Color(0.16f, 0.2f, 0.28f));
            var button = b.gameObject.AddComponent<Button>();
            button.targetGraphic = img;
            button.onClick.AddListener(() => Fire(index));
            buttonImages.Add(img);
            var icon = Rect("Icon", b, new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(42, 0), new Vector2(46, 46));
            AddImage(icon, circle, colors[i]);
            AddText(Rect("Key", icon, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero), (i + 1).ToString(), 24, TextAnchor.MiddleCenter, Color.black, FontStyle.Bold);
            AddText(Rect("Label", b, Vector2.zero, Vector2.one, new Vector2(40, 0), new Vector2(-90, 0)), labels[i], 30, TextAnchor.MiddleLeft, Color.white, FontStyle.Bold);
        }

        var tb = Rect("Target Button", panel, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0, 70), new Vector2(340, 70));
        var timg = AddImage(tb, rounded, new Color(0.1f, 0.4f, 0.3f));
        var tbutton = tb.gameObject.AddComponent<Button>();
        tbutton.targetGraphic = timg;
        tbutton.onClick.AddListener(NextTarget);
        targetLabel = AddText(Rect("Label", tb, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero), "", 26, TextAnchor.MiddleCenter, Color.white, FontStyle.Bold);
        UpdateTargetLabel();

        var msgBox = Rect("Message Image", root, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(150, 70), new Vector2(900, 90));
        AddImage(msgBox, rounded, new Color(0.06f, 0.08f, 0.12f, 0.85f));
        message = AddText(Rect("Message", msgBox, Vector2.zero, Vector2.one, Vector2.zero, new Vector2(-40, 0)),
            "Click a button, press 1-6, or use Up/Down + Space (VR trigger)", 28, TextAnchor.MiddleCenter, new Color(1f, 0.9f, 0.4f), FontStyle.Bold);
    }

    void Update()
    {
        for (int i = 0; i < labels.Length; i++)
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
                Fire(i);
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            selected = (selected + 1) % labels.Length;
            Highlight();
        }
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            selected = (selected + labels.Length - 1) % labels.Length;
            Highlight();
        }
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return)) Fire(selected);
        if (Input.GetKeyDown(KeyCode.T)) NextTarget();
    }

    void Highlight()
    {
        for (int i = 0; i < buttonImages.Count; i++)
            buttonImages[i].color = i == selected ? new Color(0.25f, 0.45f, 0.75f) : new Color(0.16f, 0.2f, 0.28f);
    }

    void NextTarget()
    {
        target = (target + 1) % 3;
        UpdateTargetLabel();
    }

    void UpdateTargetLabel()
    {
        targetLabel.text = target == 0 ? "Control: Character 1" : target == 1 ? "Control: Character 2" : "Control: Both";
    }

    void Fire(int index)
    {
        selected = index;
        Highlight();
        for (int i = 0; i < characters.Length; i++)
            if (target == 2 || target == i)
            {
                foreach (var t in triggers) characters[i].ResetTrigger(t);
                characters[i].SetTrigger(triggers[index]);
            }
        count++;
        string who = target == 0 ? "Character 1" : target == 1 ? "Character 2" : "both characters";
        message.text = index == 5
            ? $"Trigger {count}: WIN on {who}  (Win > Wave > Jump > Idle sequence)"
            : $"Trigger {count}: {labels[index]} on {who}";
    }
}
