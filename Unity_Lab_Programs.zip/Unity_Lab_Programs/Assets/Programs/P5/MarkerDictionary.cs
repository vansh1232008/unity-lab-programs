using System.Collections.Generic;
using UnityEngine;

public static class MarkerDictionary
{
    public const int Bits = 4;
    public const int Cells = Bits + 2;
    public const int MinDistance = 5;
    public static readonly int[] Codes = Build(8);

    public static int Rotate(int code)
    {
        int r = 0;
        for (int y = 0; y < Bits; y++)
        for (int x = 0; x < Bits; x++)
        {
            int bit = (code >> (y * Bits + x)) & 1;
            int nx = Bits - 1 - y, ny = x;
            r |= bit << (ny * Bits + nx);
        }
        return r;
    }

    public static int Hamming(int a, int b)
    {
        int v = a ^ b, c = 0;
        while (v != 0)
        {
            v &= v - 1;
            c++;
        }
        return c;
    }

    static int[] Build(int count)
    {
        var codes = new List<int>();
        uint state = 2463534242;
        for (int attempt = 0; attempt < 200000 && codes.Count < count; attempt++)
        {
            state ^= state << 13;
            state ^= state >> 17;
            state ^= state << 5;
            int c = (int)(state & 0xFFFF);
            int ones = Hamming(c, 0);
            if (ones < 5 || ones > 11) continue;
            int r = c;
            bool ok = true;
            for (int k = 1; k < 4 && ok; k++)
            {
                r = Rotate(r);
                if (Hamming(c, r) < MinDistance) ok = false;
            }
            foreach (int o in codes)
            {
                int ro = o;
                for (int k = 0; k < 4 && ok; k++)
                {
                    if (Hamming(c, ro) < MinDistance) ok = false;
                    ro = Rotate(ro);
                }
            }
            if (ok) codes.Add(c);
        }
        return codes.ToArray();
    }

    public static bool IsWhite(int id, int cellX, int cellY)
    {
        if (cellX == 0 || cellY == 0 || cellX == Cells - 1 || cellY == Cells - 1) return false;
        return ((Codes[id] >> ((cellY - 1) * Bits + (cellX - 1))) & 1) == 1;
    }

    public static Texture2D CreateTexture(int id, int pxPerCell, int quietCells = 1)
    {
        int n = (Cells + 2 * quietCells) * pxPerCell;
        var t = new Texture2D(n, n, TextureFormat.RGB24, false) { filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp, name = $"Marker{id}" };
        var px = new Color32[n * n];
        for (int y = 0; y < n; y++)
        for (int x = 0; x < n; x++)
        {
            int cx = x / pxPerCell - quietCells;
            int cyTop = (n - 1 - y) / pxPerCell - quietCells;
            bool white = cx < 0 || cyTop < 0 || cx >= Cells || cyTop >= Cells || IsWhite(id, cx, cyTop);
            byte v = white ? (byte)245 : (byte)18;
            px[y * n + x] = new Color32(v, v, v, 255);
        }
        t.SetPixels32(px);
        t.Apply(false);
        return t;
    }
}
