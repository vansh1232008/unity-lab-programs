using UnityEngine;

public class P5MarkerAR : MonoBehaviour
{
    public float markerSize = 0.1f;
    public int feedWidth = 640;
    public int feedHeight = 480;
    public float phoneFov = 50f;

    const int DeskLayer = 31;
    static readonly Vector3 DeskOrigin = new Vector3(0f, -500f, 0f);

    Camera main, phone, backCam;
    RenderTexture feed;
    Texture2D readTex;
    bool autoMove = true;
    Intrinsics k;
    MarkerDetector detector;
    MarkerDetection current;
    GameObject marker, model, backdrop;
    Material backdropMat;
    Texture2D dot;
    float t, yaw = 20f, pitch = 55f, dist = 0.5f, lostTimer, pop;
    bool tracking;

    Material Mat(Color c)
    {
        var m = new Material(Shader.Find("Standard"));
        m.color = c;
        return m;
    }

    GameObject Part(PrimitiveType type, Transform parent, Vector3 pos, Vector3 scale, Color c, int layer)
    {
        var go = GameObject.CreatePrimitive(type);
        Destroy(go.GetComponent<Collider>());
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().material = Mat(c);
        go.layer = layer;
        return go;
    }

    void Start()
    {
        main = Camera.main;
        main.cullingMask &= ~(1 << DeskLayer);
        main.clearFlags = CameraClearFlags.SolidColor;
        main.backgroundColor = Color.black;
        main.nearClipPlane = 0.01f;
        main.farClipPlane = 20f;
        main.depth = 0;

        backCam = new GameObject("Letterbox Camera").AddComponent<Camera>();
        backCam.clearFlags = CameraClearFlags.SolidColor;
        backCam.backgroundColor = Color.black;
        backCam.cullingMask = 0;
        backCam.depth = -10;

        BuildDesk();

        feed = new RenderTexture(feedWidth, feedHeight, 24, RenderTextureFormat.ARGB32) { antiAliasing = 2 };
        readTex = new Texture2D(feedWidth, feedHeight, TextureFormat.RGBA32, false);
        phone = new GameObject("Phone Camera").AddComponent<Camera>();
        phone.cullingMask = 1 << DeskLayer;
        phone.targetTexture = feed;
        phone.fieldOfView = phoneFov;
        phone.nearClipPlane = 0.02f;
        phone.farClipPlane = 30f;
        phone.clearFlags = CameraClearFlags.SolidColor;
        phone.backgroundColor = new Color(0.55f, 0.6f, 0.65f);
        phone.enabled = false;

        detector = new MarkerDetector { MarkerSize = markerSize };
        k = Intrinsics.FromVerticalFov(feedWidth, feedHeight, phoneFov);

        backdropMat = new Material(Shader.Find("Unlit/Texture")) { mainTexture = feed };
        backdrop = GameObject.CreatePrimitive(PrimitiveType.Quad);
        backdrop.name = "Camera Feed Backdrop";
        Destroy(backdrop.GetComponent<Collider>());
        backdrop.GetComponent<Renderer>().material = backdropMat;
        backdrop.transform.SetParent(main.transform, false);

        BuildModel();

        dot = new Texture2D(1, 1);
        dot.SetPixel(0, 0, Color.white);
        dot.Apply();
    }

    void SetLayer(GameObject go)
    {
        go.layer = DeskLayer;
        foreach (Transform c in go.transform) SetLayer(c.gameObject);
    }

    void BuildDesk()
    {
        var root = new GameObject("Simulated Real World (Desk)").transform;
        root.position = DeskOrigin;
        Part(PrimitiveType.Cube, root, new Vector3(0f, -0.03f, 0f), new Vector3(1.6f, 0.06f, 1f), new Color(0.55f, 0.36f, 0.2f), DeskLayer);
        Part(PrimitiveType.Cube, root, new Vector3(0f, 0.6f, 0.9f), new Vector3(3f, 1.3f, 0.05f), new Color(0.78f, 0.76f, 0.7f), DeskLayer);
        Part(PrimitiveType.Cube, root, new Vector3(0f, 0.001f, 0f), new Vector3(0.21f, 0.002f, 0.297f), new Color(0.96f, 0.96f, 0.94f), DeskLayer);
        Part(PrimitiveType.Cylinder, root, new Vector3(0.3f, 0.05f, 0.12f), new Vector3(0.08f, 0.05f, 0.08f), new Color(0.2f, 0.45f, 0.8f), DeskLayer);
        Part(PrimitiveType.Cube, root, new Vector3(-0.32f, 0.015f, -0.05f), new Vector3(0.17f, 0.03f, 0.24f), new Color(0.75f, 0.2f, 0.2f), DeskLayer);
        Part(PrimitiveType.Cube, root, new Vector3(-0.3f, 0.005f, 0.25f), new Vector3(0.15f, 0.01f, 0.012f), new Color(0.1f, 0.1f, 0.1f), DeskLayer);

        marker = GameObject.CreatePrimitive(PrimitiveType.Quad);
        marker.name = "Marker (id 0)";
        Destroy(marker.GetComponent<Collider>());
        marker.transform.SetParent(root, false);
        marker.transform.localPosition = new Vector3(0f, 0.0025f, 0f);
        marker.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
        float full = markerSize * (MarkerDictionary.Cells + 2) / MarkerDictionary.Cells;
        marker.transform.localScale = new Vector3(full, full, 1f);
        var mm = new Material(Shader.Find("Unlit/Texture")) { mainTexture = MarkerDictionary.CreateTexture(0, 16, 1) };
        marker.GetComponent<Renderer>().material = mm;
        SetLayer(root.gameObject);
    }

    void BuildModel()
    {
        model = new GameObject("AR Model (Sphere)");
        var s = markerSize;
        var shadow = Part(PrimitiveType.Cylinder, model.transform, new Vector3(0f, 0.001f, 0f), new Vector3(s * 0.6f, 0.0005f, s * 0.6f), Color.black, 0);
        shadow.GetComponent<Renderer>().material = new Material(Shader.Find("Sprites/Default")) { color = new Color(0f, 0f, 0f, 0.35f) };
        Part(PrimitiveType.Sphere, model.transform, new Vector3(0f, s * 0.35f, 0f), Vector3.one * s * 0.6f, new Color(0.2f, 0.6f, 1f), 0);
        model.SetActive(false);
    }

    void MovePhone()
    {
        if (Input.GetKey(KeyCode.LeftArrow)) yaw -= 50f * Time.deltaTime;
        if (Input.GetKey(KeyCode.RightArrow)) yaw += 50f * Time.deltaTime;
        if (Input.GetKey(KeyCode.UpArrow)) pitch = Mathf.Min(85f, pitch + 35f * Time.deltaTime);
        if (Input.GetKey(KeyCode.DownArrow)) pitch = Mathf.Max(20f, pitch - 35f * Time.deltaTime);
        dist = Mathf.Clamp(dist - Input.mouseScrollDelta.y * 0.03f, 0.2f, 1.2f);
        if (Input.GetKey(KeyCode.W)) dist = Mathf.Max(0.2f, dist - 0.3f * Time.deltaTime);
        if (Input.GetKey(KeyCode.S)) dist = Mathf.Min(1.2f, dist + 0.3f * Time.deltaTime);
        if (autoMove) t += Time.deltaTime;
        float y = yaw + (autoMove ? 35f * Mathf.Sin(t * 0.4f) : 0f);
        float p = pitch + (autoMove ? 10f * Mathf.Sin(t * 0.3f) : 0f);
        float d = dist + (autoMove ? 0.1f * Mathf.Sin(t * 0.25f) : 0f);
        Vector3 target = DeskOrigin + new Vector3(0.02f * Mathf.Sin(t * 1.3f), 0f, 0.02f * Mathf.Cos(t * 1.1f));
        Vector3 dir = Quaternion.Euler(p, y, 0f) * Vector3.back;
        phone.transform.position = target + dir * d;
        phone.transform.LookAt(target);
        phone.transform.Rotate(0f, 0f, 4f * Mathf.Sin(t * 0.7f), Space.Self);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)) autoMove = !autoMove;
        if (Input.GetKeyDown(KeyCode.H)) marker.SetActive(!marker.activeSelf);

        MovePhone();
        phone.Render();
        var prev = RenderTexture.active;
        RenderTexture.active = feed;
        readTex.ReadPixels(new Rect(0, 0, feedWidth, feedHeight), 0, 0, false);
        RenderTexture.active = prev;
        Color32[] px = readTex.GetPixels32();
        int w = feedWidth, h = feedHeight;

        detector.Process(px, w, h, k);
        current = null;
        foreach (var d in detector.Detections)
            if (d.Id == 0) { current = d; break; }

        Layout(w, h);
        if (current != null)
        {
            if (!tracking) pop = 0f;
            tracking = true;
            lostTimer = 0.2f;
            ApplyPose(current);
            model.SetActive(true);
        }
        else
        {
            lostTimer -= Time.deltaTime;
            if (lostTimer <= 0f)
            {
                tracking = false;
                model.SetActive(false);
            }
        }
        pop = Mathf.Min(1f, pop + Time.deltaTime * 3f);
        float e = 1f + 2.7f * Mathf.Pow(pop - 1f, 3f) + 1.7f * Mathf.Pow(pop - 1f, 2f);
        model.transform.localScale = Vector3.one * Mathf.Max(0.01f, e);
        model.transform.rotation = Quaternion.Euler(0f, Time.time * 40f, 0f);
    }

    void Layout(int w, int h)
    {
        if (w < 2 || h < 2) return;
        float feedAspect = w / (float)h;
        float screenAspect = Screen.width / (float)Screen.height;
        if (screenAspect > feedAspect)
        {
            float rw = feedAspect / screenAspect;
            main.rect = new Rect((1f - rw) * 0.5f, 0f, rw, 1f);
        }
        else
        {
            float rh = screenAspect / feedAspect;
            main.rect = new Rect(0f, (1f - rh) * 0.5f, 1f, rh);
        }
        main.fieldOfView = 2f * Mathf.Atan((float)(h * 0.5 / k.Fy)) * Mathf.Rad2Deg;
        main.aspect = feedAspect;
        float dd = 15f;
        float hh = 2f * dd * Mathf.Tan(main.fieldOfView * 0.5f * Mathf.Deg2Rad);
        backdrop.transform.localPosition = new Vector3(0f, 0f, dd);
        backdrop.transform.localRotation = Quaternion.identity;
        backdrop.transform.localScale = new Vector3(hh * feedAspect, hh, 1f);
    }

    static Vector3 M(Vector3 v) => new Vector3(v.x, v.z, v.y);

    void ApplyPose(MarkerDetection d)
    {
        var R = d.R;
        var t3 = d.T;
        Vector3 cm = new Vector3(
            (float)-(R[0] * t3[0] + R[3] * t3[1] + R[6] * t3[2]),
            (float)-(R[1] * t3[0] + R[4] * t3[1] + R[7] * t3[2]),
            (float)-(R[2] * t3[0] + R[5] * t3[1] + R[8] * t3[2]));
        Vector3 down = new Vector3((float)R[3], (float)R[4], (float)R[5]);
        Vector3 fwd = new Vector3((float)R[6], (float)R[7], (float)R[8]);
        main.transform.SetPositionAndRotation(M(cm), Quaternion.LookRotation(M(fwd), -M(down)));
    }

    Vector2 ToScreen(Vector2 p, int w, int h)
    {
        Rect r = main.pixelRect;
        return new Vector2(r.x + p.x / w * r.width, Screen.height - r.yMax + p.y / h * r.height);
    }

    void OnGUI()
    {
        int w = feedWidth, h = feedHeight;
        if (current != null)
        {
            GUI.color = new Color(0.2f, 1f, 0.3f);
            for (int i = 0; i < 4; i++)
            {
                Vector2 a = ToScreen(current.Corners[i], w, h);
                Vector2 b = ToScreen(current.Corners[(i + 1) & 3], w, h);
                for (int s = 0; s <= 20; s++)
                {
                    Vector2 p = Vector2.Lerp(a, b, s / 20f);
                    GUI.DrawTexture(new Rect(p.x - 2, p.y - 2, 4, 4), dot);
                }
            }
            GUI.color = Color.white;
        }
        GUI.Box(new Rect(10, 10, 360, 110),
            "PROGRAM 5 - Marker-based AR\n\n" +
            (current != null ? "Marker detected: model placed on the marker" : "Searching for marker...") +
            "\n\nArrows = move camera,  W/S = closer/farther\nH = hide/show marker");
    }
}
