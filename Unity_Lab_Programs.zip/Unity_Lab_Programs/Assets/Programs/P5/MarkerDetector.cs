using System;
using System.Collections.Generic;
using UnityEngine;

public struct Intrinsics
{
    public double Fx, Fy, Cx, Cy;

    public static Intrinsics FromVerticalFov(int width, int height, float fovDeg)
    {
        double fy = height * 0.5 / Math.Tan(fovDeg * Math.PI / 360.0);
        return new Intrinsics { Fx = fy, Fy = fy, Cx = width * 0.5, Cy = height * 0.5 };
    }
}

public sealed class MarkerDetection
{
    public int Id;
    public Vector2[] Corners = new Vector2[4];
    public double[] R = new double[9];
    public double[] T = new double[3];
    public float ReprojectionError;
    public int BitErrors;
}

public sealed class MarkerDetector
{
    public int Width { get; private set; }
    public int Height { get; private set; }
    public float MarkerSize = 0.12f;
    public int ThresholdRadius = 11;
    public int ThresholdOffset = 8;

    public byte[] Gray;
    public byte[] Binary;
    public readonly List<Vector2[]> Candidates = new List<Vector2[]>();
    public readonly List<MarkerDetection> Detections = new List<MarkerDetection>();
    public int ComponentCount;

    int[] labels, parent, integral;
    readonly List<int> boundary = new List<int>();

    void Ensure(int w, int h)
    {
        if (w == Width && h == Height && Gray != null) return;
        Width = w;
        Height = h;
        Gray = new byte[w * h];
        Binary = new byte[w * h];
        labels = new int[w * h];
        integral = new int[(w + 1) * (h + 1)];
        parent = new int[w * h / 2 + 2];
    }

    public void Process(Color32[] px, int w, int h, Intrinsics k)
    {
        Ensure(w, h);
        for (int y = 0; y < h; y++)
        {
            int src = (h - 1 - y) * w, dst = y * w;
            for (int x = 0; x < w; x++)
            {
                var c = px[src + x];
                Gray[dst + x] = (byte)((c.r * 77 + c.g * 150 + c.b * 29) >> 8);
            }
        }
        Threshold();
        Label();
        Detections.Clear();
        for (int i = 0; i < Candidates.Count; i++)
        {
            var det = Decode(Candidates[i]);
            if (det == null) continue;
            EstimatePose(det, k);
            Detections.Add(det);
        }
    }

    void Threshold()
    {
        int w = Width, h = Height, W = w + 1;
        for (int y = 0; y < h; y++)
        {
            int row = 0;
            for (int x = 0; x < w; x++)
            {
                row += Gray[y * w + x];
                integral[(y + 1) * W + x + 1] = integral[y * W + x + 1] + row;
            }
        }
        int r = ThresholdRadius;
        for (int y = 0; y < h; y++)
        {
            int y0 = Math.Max(0, y - r), y1 = Math.Min(h, y + r + 1);
            for (int x = 0; x < w; x++)
            {
                int x0 = Math.Max(0, x - r), x1 = Math.Min(w, x + r + 1);
                int sum = integral[y1 * W + x1] - integral[y0 * W + x1] - integral[y1 * W + x0] + integral[y0 * W + x0];
                int area = (x1 - x0) * (y1 - y0);
                Binary[y * w + x] = (byte)(Gray[y * w + x] * area < sum - ThresholdOffset * area ? 1 : 0);
            }
        }
    }

    int Find(int a)
    {
        while (parent[a] != a)
        {
            parent[a] = parent[parent[a]];
            a = parent[a];
        }
        return a;
    }

    void Label()
    {
        int w = Width, h = Height;
        int next = 1;
        parent[0] = 0;
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            int i = y * w + x;
            if (Binary[i] == 0)
            {
                labels[i] = 0;
                continue;
            }
            int left = x > 0 ? labels[i - 1] : 0;
            int up = y > 0 ? labels[i - w] : 0;
            if (left == 0 && up == 0)
            {
                if (next >= parent.Length) Array.Resize(ref parent, parent.Length * 2);
                parent[next] = next;
                labels[i] = next++;
            }
            else if (left != 0 && up != 0)
            {
                int a = Find(left), b = Find(up);
                if (a != b) parent[Math.Max(a, b)] = Math.Min(a, b);
                labels[i] = Math.Min(a, b);
            }
            else labels[i] = left != 0 ? left : up;
        }

        var minX = new Dictionary<int, int>();
        var stats = new Dictionary<int, int[]>();
        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            int i = y * w + x;
            if (labels[i] == 0) continue;
            int l = Find(labels[i]);
            labels[i] = l;
            if (!stats.TryGetValue(l, out var s))
            {
                s = new[] { 0, x, x, y, y };
                stats[l] = s;
            }
            s[0]++;
            if (x < s[1]) s[1] = x;
            if (x > s[2]) s[2] = x;
            if (y < s[3]) s[3] = y;
            if (y > s[4]) s[4] = y;
        }
        ComponentCount = stats.Count;

        Candidates.Clear();
        foreach (var kv in stats)
        {
            var s = kv.Value;
            int bw = s[2] - s[1] + 1, bh = s[4] - s[3] + 1;
            if (s[0] < 100 || bw < 14 || bh < 14) continue;
            if (s[1] <= 1 || s[3] <= 1 || s[2] >= w - 2 || s[4] >= h - 2) continue;
            if (bw > w * 0.9f || bh > h * 0.9f) continue;
            float aspect = bw > bh ? bw / (float)bh : bh / (float)bw;
            if (aspect > 6f) continue;
            var quad = FitQuad(kv.Key, s);
            if (quad != null) Candidates.Add(quad);
        }
    }

    static float Cross(Vector2 a, Vector2 b, Vector2 p) => (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x);

    Vector2[] FitQuad(int label, int[] s)
    {
        int w = Width;
        boundary.Clear();
        for (int y = s[3]; y <= s[4]; y++)
        {
            int first = -1, last = -1;
            for (int x = s[1]; x <= s[2]; x++)
            {
                if (labels[y * w + x] != label) continue;
                if (first < 0) first = x;
                last = x;
            }
            if (first < 0) continue;
            boundary.Add(y * w + first);
            if (last != first) boundary.Add(y * w + last);
        }
        for (int x = s[1]; x <= s[2]; x++)
        {
            int first = -1, last = -1;
            for (int y = s[3]; y <= s[4]; y++)
            {
                if (labels[y * w + x] != label) continue;
                if (first < 0) first = y;
                last = y;
            }
            if (first < 0) continue;
            boundary.Add(first * w + x);
            if (last != first) boundary.Add(last * w + x);
        }
        if (boundary.Count < 40) return null;

        Vector2 P(int i) => new Vector2(i % w + 0.5f, i / w + 0.5f);
        Vector2 centroid = Vector2.zero;
        foreach (int i in boundary) centroid += P(i);
        centroid /= boundary.Count;

        Vector2 c0 = centroid, c2;
        float best = -1f;
        foreach (int i in boundary)
        {
            float d = (P(i) - centroid).sqrMagnitude;
            if (d > best)
            {
                best = d;
                c0 = P(i);
            }
        }
        best = -1f;
        c2 = c0;
        foreach (int i in boundary)
        {
            float d = (P(i) - c0).sqrMagnitude;
            if (d > best)
            {
                best = d;
                c2 = P(i);
            }
        }
        Vector2 c1 = c0, c3 = c0;
        float bp = 0f, bn = 0f;
        foreach (int i in boundary)
        {
            float cr = Cross(c0, c2, P(i));
            if (cr > bp)
            {
                bp = cr;
                c1 = P(i);
            }
            if (cr < bn)
            {
                bn = cr;
                c3 = P(i);
            }
        }
        float diag = (c2 - c0).magnitude;
        if (bp < diag * diag * 0.12f || -bn < diag * diag * 0.12f) return null;
        var q = new[] { c0, c1, c2, c3 };
        if (Shoelace(q) < 0f) q = new[] { c0, c3, c2, c1 };

        int far = 0;
        foreach (int i in boundary)
        {
            Vector2 p = P(i);
            float dmin = float.MaxValue;
            for (int e = 0; e < 4; e++) dmin = Mathf.Min(dmin, SegDist(p, q[e], q[(e + 1) & 3]));
            if (dmin > 2.2f + diag * 0.012f) far++;
        }
        if (far > boundary.Count * 0.12f) return null;

        var lines = new Vector3[4];
        for (int e = 0; e < 4; e++)
        {
            Vector2 a = q[e], b = q[(e + 1) & 3];
            Vector2 dir = (b - a).normalized;
            float len = (b - a).magnitude;
            double sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0;
            int n = 0;
            foreach (int i in boundary)
            {
                Vector2 p = P(i);
                float t = Vector2.Dot(p - a, dir) / len;
                if (t < 0.1f || t > 0.9f) continue;
                if (Mathf.Abs(Cross(a, b, p)) / len > 2.5f) continue;
                sx += p.x;
                sy += p.y;
                sxx += p.x * p.x;
                syy += p.y * p.y;
                sxy += p.x * p.y;
                n++;
            }
            if (n < 6) return q;
            double mx = sx / n, my = sy / n;
            double cxx = sxx / n - mx * mx, cyy = syy / n - my * my, cxy = sxy / n - mx * my;
            double ang = 0.5 * Math.Atan2(2 * cxy, cxx - cyy);
            var ld = new Vector2((float)Math.Cos(ang), (float)Math.Sin(ang));
            var nrm = new Vector2(-ld.y, ld.x);
            var m = new Vector2((float)mx, (float)my);
            if (Vector2.Dot(nrm, m - centroid) < 0f) nrm = -nrm;
            m += nrm * 0.5f;
            lines[e] = new Vector3(nrm.x, nrm.y, -Vector2.Dot(nrm, m));
        }
        var refined = new Vector2[4];
        for (int c = 0; c < 4; c++)
        {
            var l1 = lines[(c + 3) & 3];
            var l2 = lines[c];
            float det = l1.x * l2.y - l2.x * l1.y;
            if (Mathf.Abs(det) < 1e-5f) return q;
            refined[c] = new Vector2((l1.y * l2.z - l2.y * l1.z) / det, (l2.x * l1.z - l1.x * l2.z) / det);
            if ((refined[c] - q[c]).sqrMagnitude > 9f) return q;
        }
        return refined;
    }

    static float Shoelace(Vector2[] q)
    {
        float s = 0f;
        for (int i = 0; i < 4; i++) s += q[i].x * q[(i + 1) & 3].y - q[(i + 1) & 3].x * q[i].y;
        return s;
    }

    static float SegDist(Vector2 p, Vector2 a, Vector2 b)
    {
        Vector2 ab = b - a;
        float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / Mathf.Max(1e-6f, ab.sqrMagnitude));
        return (a + ab * t - p).magnitude;
    }

    float Sample(float x, float y)
    {
        x -= 0.5f;
        y -= 0.5f;
        int x0 = Mathf.Clamp((int)Mathf.Floor(x), 0, Width - 2), y0 = Mathf.Clamp((int)Mathf.Floor(y), 0, Height - 2);
        float fx = Mathf.Clamp01(x - x0), fy = Mathf.Clamp01(y - y0);
        int i = y0 * Width + x0;
        float a = Gray[i] + (Gray[i + 1] - Gray[i]) * fx;
        float b = Gray[i + Width] + (Gray[i + Width + 1] - Gray[i + Width]) * fx;
        return a + (b - a) * fy;
    }

    MarkerDetection Decode(Vector2[] q)
    {
        const int n = MarkerDictionary.Cells;
        var dst = new double[8];
        for (int i = 0; i < 4; i++)
        {
            dst[2 * i] = q[i].x;
            dst[2 * i + 1] = q[i].y;
        }
        var hm = Homography(new double[] { 0, 0, n, 0, n, n, 0, n }, dst);
        if (hm == null) return null;
        var cells = new float[n * n];
        float lo = 255f, hi = 0f;
        for (int cy = 0; cy < n; cy++)
        for (int cx = 0; cx < n; cx++)
        {
            float s = 0f;
            for (int sy = -1; sy <= 1; sy++)
            for (int sx = -1; sx <= 1; sx++)
            {
                double u = cx + 0.5 + sx * 0.22, v = cy + 0.5 + sy * 0.22;
                double zw = hm[6] * u + hm[7] * v + 1.0;
                s += Sample((float)((hm[0] * u + hm[1] * v + hm[2]) / zw), (float)((hm[3] * u + hm[4] * v + hm[5]) / zw));
            }
            s /= 9f;
            cells[cy * n + cx] = s;
            lo = Mathf.Min(lo, s);
            hi = Mathf.Max(hi, s);
        }
        if (hi - lo < 30f) return null;
        float thr = (lo + hi) * 0.5f;
        int borderWhite = 0;
        for (int i = 0; i < n; i++)
        {
            if (cells[i] > thr) borderWhite++;
            if (cells[(n - 1) * n + i] > thr) borderWhite++;
            if (i > 0 && i < n - 1)
            {
                if (cells[i * n] > thr) borderWhite++;
                if (cells[i * n + n - 1] > thr) borderWhite++;
            }
        }
        if (borderWhite > 2) return null;

        int code = 0;
        for (int y = 0; y < MarkerDictionary.Bits; y++)
        for (int x = 0; x < MarkerDictionary.Bits; x++)
            if (cells[(y + 1) * n + x + 1] > thr)
                code |= 1 << (y * MarkerDictionary.Bits + x);

        int rotated = code;
        for (int k = 0; k < 4; k++)
        {
            for (int id = 0; id < MarkerDictionary.Codes.Length; id++)
            {
                int dist = MarkerDictionary.Hamming(rotated, MarkerDictionary.Codes[id]);
                if (dist > 1) continue;
                var det = new MarkerDetection { Id = id, BitErrors = dist };
                for (int c = 0; c < 4; c++) det.Corners[c] = q[(c + 4 - k) & 3];
                return det;
            }
            rotated = MarkerDictionary.Rotate(rotated);
        }
        return null;
    }

    public static double[] Homography(double[] src, double[] dst)
    {
        var a = new double[8, 9];
        for (int i = 0; i < 4; i++)
        {
            double x = src[2 * i], y = src[2 * i + 1], u = dst[2 * i], v = dst[2 * i + 1];
            int r = 2 * i;
            a[r, 0] = x; a[r, 1] = y; a[r, 2] = 1; a[r, 6] = -u * x; a[r, 7] = -u * y; a[r, 8] = u;
            a[r + 1, 3] = x; a[r + 1, 4] = y; a[r + 1, 5] = 1; a[r + 1, 6] = -v * x; a[r + 1, 7] = -v * y; a[r + 1, 8] = v;
        }
        return Solve(a, 8);
    }

    static double[] Solve(double[,] a, int n)
    {
        for (int c = 0; c < n; c++)
        {
            int piv = c;
            for (int r = c + 1; r < n; r++)
                if (Math.Abs(a[r, c]) > Math.Abs(a[piv, c]))
                    piv = r;
            if (Math.Abs(a[piv, c]) < 1e-12) return null;
            if (piv != c)
                for (int k = c; k <= n; k++)
                    (a[c, k], a[piv, k]) = (a[piv, k], a[c, k]);
            for (int r = 0; r < n; r++)
            {
                if (r == c) continue;
                double f = a[r, c] / a[c, c];
                if (f == 0) continue;
                for (int k = c; k <= n; k++) a[r, k] -= f * a[c, k];
            }
        }
        var x = new double[n];
        for (int i = 0; i < n; i++) x[i] = a[i, n] / a[i, i];
        return x;
    }

    double[] ObjectPoints()
    {
        double h = MarkerSize * 0.5;
        return new[] { -h, h, h, h, h, -h, -h, -h };
    }

    void EstimatePose(MarkerDetection det, Intrinsics k)
    {
        var obj = ObjectPoints();
        var img = new double[8];
        for (int i = 0; i < 4; i++)
        {
            img[2 * i] = det.Corners[i].x;
            img[2 * i + 1] = det.Corners[i].y;
        }
        var hm = Homography(obj, img);
        if (hm == null) return;
        double[] Col(int c)
        {
            double h0 = hm[c], h1 = hm[3 + c], h2 = c == 2 ? 1.0 : hm[6 + c];
            return new[] { (h0 - k.Cx * h2) / k.Fx, (h1 - k.Cy * h2) / k.Fy, h2 };
        }
        var a1 = Col(0);
        var a2 = Col(1);
        var a3 = Col(2);
        double lambda = 2.0 / (Norm(a1) + Norm(a2));
        if (a3[2] * lambda < 0) lambda = -lambda;
        var r1 = Scale(a1, lambda);
        var r2 = Scale(a2, lambda);
        var t = Scale(a3, lambda);
        var r3 = Normalize(CrossD(r1, r2));
        var c = Normalize(Add(r1, r2));
        var d = Normalize(CrossD(c, r3));
        var nr1 = Scale(Add(c, d), 1.0 / Math.Sqrt(2));
        var nr2 = Scale(Sub(c, d), 1.0 / Math.Sqrt(2));
        var nr3 = CrossD(nr1, nr2);
        var R = new[] { nr1[0], nr2[0], nr3[0], nr1[1], nr2[1], nr3[1], nr1[2], nr2[2], nr3[2] };

        Refine(R, t, obj, img, k);
        Array.Copy(R, det.R, 9);
        Array.Copy(t, det.T, 3);
        det.ReprojectionError = (float)Math.Sqrt(Residual(R, t, obj, img, k, null) / 4.0);
    }

    static double Residual(double[] R, double[] t, double[] obj, double[] img, Intrinsics k, double[] res)
    {
        double s = 0;
        for (int i = 0; i < 4; i++)
        {
            double x = obj[2 * i], y = obj[2 * i + 1];
            double cx = R[0] * x + R[1] * y + t[0];
            double cy = R[3] * x + R[4] * y + t[1];
            double cz = R[6] * x + R[7] * y + t[2];
            double u = k.Fx * cx / cz + k.Cx, v = k.Fy * cy / cz + k.Cy;
            double du = u - img[2 * i], dv = v - img[2 * i + 1];
            if (res != null)
            {
                res[2 * i] = du;
                res[2 * i + 1] = dv;
            }
            s += du * du + dv * dv;
        }
        return s;
    }

    static double[] Rodrigues(double wx, double wy, double wz)
    {
        double th = Math.Sqrt(wx * wx + wy * wy + wz * wz);
        if (th < 1e-12) return new double[] { 1, -wz, wy, wz, 1, -wx, -wy, wx, 1 };
        double kx = wx / th, ky = wy / th, kz = wz / th, c = Math.Cos(th), s = Math.Sin(th), v = 1 - c;
        return new[]
        {
            c + kx * kx * v, kx * ky * v - kz * s, kx * kz * v + ky * s,
            ky * kx * v + kz * s, c + ky * ky * v, ky * kz * v - kx * s,
            kz * kx * v - ky * s, kz * ky * v + kx * s, c + kz * kz * v,
        };
    }

    static double[] Mul(double[] a, double[] b)
    {
        var r = new double[9];
        for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            r[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j];
        return r;
    }

    static void Refine(double[] R, double[] t, double[] obj, double[] img, Intrinsics k)
    {
        var res = new double[8];
        var res2 = new double[8];
        var J = new double[8, 6];
        double mu = 1e-3;
        double err = Residual(R, t, obj, img, k, res);
        for (int it = 0; it < 15; it++)
        {
            const double eps = 1e-6;
            for (int p = 0; p < 6; p++)
            {
                double[] Rp = R, tp = (double[])t.Clone();
                if (p < 3) Rp = Mul(Rodrigues(p == 0 ? eps : 0, p == 1 ? eps : 0, p == 2 ? eps : 0), R);
                else tp[p - 3] += eps;
                Residual(Rp, tp, obj, img, k, res2);
                for (int r = 0; r < 8; r++) J[r, p] = (res2[r] - res[r]) / eps;
            }
            var a = new double[6, 7];
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    double s = 0;
                    for (int r = 0; r < 8; r++) s += J[r, i] * J[r, j];
                    a[i, j] = s + (i == j ? mu * (1 + s) : 0);
                }
                double g = 0;
                for (int r = 0; r < 8; r++) g += J[r, i] * res[r];
                a[i, 6] = -g;
            }
            var delta = Solve(a, 6);
            if (delta == null) break;
            var Rn = Mul(Rodrigues(delta[0], delta[1], delta[2]), R);
            var tn = new[] { t[0] + delta[3], t[1] + delta[4], t[2] + delta[5] };
            double e2 = Residual(Rn, tn, obj, img, k, res2);
            if (e2 < err)
            {
                Array.Copy(Rn, R, 9);
                Array.Copy(tn, t, 3);
                Array.Copy(res2, res, 8);
                bool small = err - e2 < 1e-10;
                err = e2;
                mu *= 0.3;
                if (small) break;
            }
            else mu *= 10;
        }
    }

    static double Norm(double[] a) => Math.Sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
    static double[] Scale(double[] a, double s) => new[] { a[0] * s, a[1] * s, a[2] * s };
    static double[] Add(double[] a, double[] b) => new[] { a[0] + b[0], a[1] + b[1], a[2] + b[2] };
    static double[] Sub(double[] a, double[] b) => new[] { a[0] - b[0], a[1] - b[1], a[2] - b[2] };
    static double[] Normalize(double[] a) => Scale(a, 1.0 / Math.Max(1e-12, Norm(a)));
    static double[] CrossD(double[] a, double[] b) => new[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] };

    public static Vector2 Project(MarkerDetection d, Intrinsics k, double x, double y, double z)
    {
        var R = d.R;
        double cx = R[0] * x + R[1] * y + R[2] * z + d.T[0];
        double cy = R[3] * x + R[4] * y + R[5] * z + d.T[1];
        double cz = R[6] * x + R[7] * y + R[8] * z + d.T[2];
        return new Vector2((float)(k.Fx * cx / cz + k.Cx), (float)(k.Fy * cy / cz + k.Cy));
    }
}
